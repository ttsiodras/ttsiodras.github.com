/*
 *  trender - 3D Studio .ASC files realtime renderer
 *  Copyright (C) 1999  Thanassis Tsiodras (ttsiod@softlab.ntua.gr)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef __3DTYPES_INCLUDED__
#define __3DTYPES_INCLUDED__

#include <stdio.h>

#include "types.h"
#include "misc.h"
#include "camera.h"

#define MAXZDEPTH 16384

class Light {
    UCHAR r,g,b;
    UCHAR intensity;
    FLOAT x,y,z;
public:
    Light(UCHAR rr, UCHAR gg, UCHAR bb,
          UCHAR inten,
          FLOAT xx, FLOAT yy, FLOAT zz)
    {
        r = rr; g = gg; b = bb;
        intensity = inten;
        x = xx; y = yy; z = zz;
    }
    FLOAT GetX() { return x; }
    FLOAT GetY() { return y; }
    FLOAT GetZ() { return z; }
    void SetPosition(FLOAT xx,FLOAT yy,FLOAT zz) { x = xx; y = yy; z = zz; }
};

class Object3D;

class Material {
    UCHAR ucR, ucG, ucB;
    char *szMaterial;
    Material *next;
public:
    Material(Object3D *object, int r, int g, int b);
    Material(Object3D *object, char *s);
    ~Material() { delete [] szMaterial; }
    const char *GetMaterialName(void) { return (const char *) szMaterial; }
    Material *GetNextNode() { return next; }
    UCHAR GetR() { return ucR; }
    UCHAR GetG() { return ucG; }
    UCHAR GetB() { return ucB; }
};

struct Vertex {  
    FLOAT usX, usY, usZ;
    FLOAT fTransformedX, fTransformedY, fTransformedZ;
    FLOAT fNormalX, fNormalY, fNormalZ;
    BOOLEAN always_draw;
    FLOAT intensity;

    init(FLOAT x, FLOAT y, FLOAT z);
    void Transform(Camera *);

    BOOLEAN IsAlways(void) { return always_draw; }
    FLOAT GetTransformedX() { return fTransformedX; }
    FLOAT GetTransformedY() { return fTransformedY; }
    FLOAT GetTransformedZ() { return fTransformedZ; }

    FLOAT GetX() { return usX; }
    FLOAT GetY() { return usY; }
    FLOAT GetZ() { return usZ; }

    FLOAT GetNormalX() { return fNormalX; }
    FLOAT GetNormalY() { return fNormalY; }
    FLOAT GetNormalZ() { return fNormalZ; }

    FLOAT GetIntensity() { return intensity; }
    void SetIntensity(FLOAT inten) { intensity=inten; }

    void SetNormals(FLOAT fx, FLOAT fy, FLOAT fz) {
        fNormalX = fx;
        fNormalY = fy;
        fNormalZ = fz;
    }
    void SetAlways(void) { always_draw = TRUE; }

    void AddToNormal(FLOAT fx, FLOAT fy, FLOAT fz) {
        fNormalX += fx;
        fNormalY += fy;
        fNormalZ += fz;
    }
    void Illuminate(Light *light, Camera *camera);
};

struct Triangle {
    Vertex *v0, *v1, *v2;
    FLOAT fCenterX, fCenterY, fCenterZ;
    FLOAT fNormalX, fNormalY, fNormalZ;
    Material *material;
    BOOLEAN visible;

    init(Vertex *a, Vertex *b, Vertex *c, Material*m);
    Material *GetMaterial() { return material; }

    BOOLEAN IsVisible() { return visible; }
    void SetVisible(BOOLEAN b) { visible = b; }

    Vertex *GetV0() { return v0; }
    Vertex *GetV1() { return v1; }
    Vertex *GetV2() { return v2; }
    FLOAT GetCenterX() { return fCenterX; }
    FLOAT GetCenterY() { return fCenterY; }
    FLOAT GetCenterZ() { return fCenterZ; }

    FLOAT GetNormalX() { return fNormalX; }
    FLOAT GetNormalY() { return fNormalY; }
    FLOAT GetNormalZ() { return fNormalZ; }

    void SetNormals( FLOAT fx, FLOAT fy, FLOAT fz) {
        fNormalX = fx;
        fNormalY = fy;
        fNormalZ = fz;
    }
};

class Object3D {
    char *szObjectName;
    char *szFileName;

    Vertex *headVertex;
    Triangle *headTriangle;
    Material *headMaterial;

    Material *white;

    FLOAT radiusX, radiusY, radiusZ;
    LONG lTotalVertexes, lTotalTriangles;

    void load_object(char *szFname, FLOAT fScale);
    void fix_normals(void);

public:    
    Object3D(char *szFname, FLOAT fScale=1.0) {
        headVertex = NULL;
        headTriangle = NULL;
        headMaterial = NULL;

        white = new Material(this, "\"r128g128b128a0\"");

        load_object(szFname, fScale);
        fix_normals();
    }
    ~Object3D();

    Vertex* GetHeadVertex() { return headVertex; }
    SetHeadVertex(Vertex *newHead) { headVertex = newHead; }
    
    Triangle* GetHeadTriangle() { return headTriangle; }
    SetHeadTriangle(Triangle *newHead) { headTriangle = newHead; }

    Material* GetHeadMaterial() { return headMaterial; }
    SetHeadMaterial(Material *newHead) { headMaterial = newHead; }

    FLOAT GetRadiusX(void) { return radiusX; }
    FLOAT GetRadiusY(void) { return radiusY; }
    FLOAT GetRadiusZ(void) { return radiusZ; }

    void SetRadiusX(FLOAT ra) { radiusX=ra; }
    void SetRadiusY(FLOAT ra) { radiusY=ra; }
    void SetRadiusZ(FLOAT ra) { radiusZ=ra; }

    LONG GetNoOfVertexes(void) { return lTotalVertexes; }
    LONG GetNoOfTriangles(void) { return lTotalTriangles; }

    void RenderDots(Camera *camera);
    void RenderWireFrame(Camera *camera);
    void RenderDepthWireFrame(Camera *camera);
    LONG RenderZGouraud(Camera *camera, Light *light);
};

#endif
