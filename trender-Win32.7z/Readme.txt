This is a recompilation of trender-SDL under Win32.
Double click on runme.bat to look at the 'ludwig.asc'
object. To see other objects, edit runme.bat and substitute 
'ludwig.asc' with the path and filename of the object you want. 
The package also contains the Win32 version of SDL (SDL.DLL)
as well as a copy of the original README (below).
NOTE1:
------
After each run, a 'stdout.txt' and a 'stderr.txt' will be 
created. 'stdout.txt' contains a performace count, so check it out.
NOTE2:
------
Linux/egcs seems to be equally good at optimizing - if not better - 
than Win32/Visual C++ ! There IS a BIG price difference, however :)
====================================================================

trender SDL
A simple realtime renderer of 3D Studio .ASC files. 

Two parameters are required for a successful run:
The path of the object, and the mode of rendering:

./trender filename.asc mode

where filename.asc points to a 3D Studio ASC file, and mode is one of:

	0 : points
	1 : antialiazed lines
	2 : depth-shaded solid lines
	3 : filled polygons (no shading)
	4 : filled polygons (no shading) + solid lines
	5 : depth sorted fast Gouraud shaded polygons    (best one!)
	6 : Z-Buffer slow-but-perfect Gouraud shading

To navigate, use the cursor keys, A, Z, W, and hit ESCAPE to exit.
SPACE moves from one rendering mode to the next.

I am releasing the sources under GPL for all you youngsters that want to 
figure out how to do realtime 3D stuff on your own. Having been in your shoes, 
I know how frustrating it can be when you first try it. Hope this helps.

If you have a 3DFX, don't forget to check trender 3DFX, too.

Contact me for any comments/questions.

ttsiod@softlab.ntua.gr
Thanassis Tsiodras
