WHAT IS THIS?
=============

This package contains the Win32 binary of a simple raytracer.
I created it to familiarize myself with development of CUDA programs.

The algorithms used and the challenges I faced are documented in:

   http://users.softlab.ece.ntua.gr/~ttsiod/cudarenderer-BVH.html

The GPL source code is also there.

Compilation was done via:
- the CUDA 3.2 toolkit 
- the free edition of Visual Studio 2008 Express

Sadly, there is currently no way to use MinGW for developing
of CUDA Win32 applications.

The raytracer can read...

- .3ds objects
- .ply (ascii) objects
- a simple binary dump of triangle mesh information (.tri files). 

RUNNING
=======

Run "RUNME.bat", or equivalently

	cudaRenderer.exe chessboard.tri

or try the other available object:

	cudaRenderer.exe trainColor.ply

For more 3D objects, get the source package of my SW-only renderer on my site.
(http://users.softlab.ece.ntua.gr/~ttsiod/renderer.html)

KEYBOARD CONTROLS
-----------------

- Hit 'H' for help.
- Hit 'R' to stop/start auto-spin.
- Fly around with the cursor keys,A,Z and rotate the light with Q,W. 
- S and F are 'strafe' left/right, E and D are 'strafe' up/down.
- F4 toggles points mode
- F5 toggles specular lighting
- F6 toggles phong normal interpolation
- F7 toggles reflections
- F8 toggles shadows
- F9 toggles anti-aliasing
- ESC quits. 

Thanassis Tsiodras, Dr.-Ing.
ttsiodras_at-no-spam_thanks-gmail_dot-com
