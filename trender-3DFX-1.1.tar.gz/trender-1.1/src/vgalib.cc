/*
 *  trender - 3D Studio .ASC files realtime renderer
 *  Copyright (C) 1999  Thanassis Tsiodras (ttsiod@softlab.ntua.gr)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <string.h>
#include <stdlib.h>
#include "3dtypes.h"
#include "vgalib.h"
#include "defines.h"
#include "glide.h"

#define fastcode(xxx,yyy,ccc)		\
    ccc=0;				\
    if (xxx<0) ccc|=1;			\
    else if (xxx>MAXX-1) ccc|=2;	\
    if (yyy<0) ccc|=4;			\
    else if (yyy>MAXY-1) ccc|=8;

void mvgaline(FLOAT x1,FLOAT y1,FLOAT x2,FLOAT y2,unsigned char colour)
{
    int c,c1,c2;
    int x,y;
    int cc = colour;
    
    fastcode(x1,y1,c1);
    fastcode(x2,y2,c2);
    while ((c1!=0) || (c2!=0)) {
        if ((c1 & c2)!=0) goto L10;
        c=c1;
        if (c==0) c=c2;
        if ((c & 1)!=0)
        {
            y=(int) (y1+((y2-y1)*(-x1)/(x2-x1)));
            x=0;
        }
        else if ((c & 2)!=0)
        {
            y=(int) (y1+((y2-y1)*(MAXX-1-x1)/(x2-x1)));
            x=MAXX-1;
        }
        else if ((c & 8)!=0)
        {
            x=(int) (x1+((x2-x1)*(MAXY-1-y1)/(y2-y1)));
            y=MAXY-1;
        }
        else if ((c & 4)!=0)
        {
            x=(int) (x1+((x2-x1)*(-y1)/(y2-y1)));
            y=0;
        }
        if (c==c1)
        {
            x1=x;y1=y;
            fastcode(x1,y1,c1);
        }
        else
        {
            x2=x;y2=y;
            fastcode(x2,y2,c2);
        }
    }

    GrVertex A,B;

    A.x = x1; A.y = y1; A.a = 255.0f;
    B.x = x2; B.y = y2; B.a = 255.0f;

    grConstantColorValue(cc | (cc<<8) | (cc<<16));
    grDrawLine(&A, &B);

    L10:;
}

void mvgalineMaterial(	FLOAT x1,FLOAT y1,
			FLOAT x2,FLOAT y2, Material *mat)
{
    unsigned char c,c1,c2;
    int x,y;

    fastcode(x1,y1,c1);
    fastcode(x2,y2,c2);
    while ((c1!=0) || (c2!=0)) {
        if ((c1 & c2)!=0) goto L10;
        c=c1;
        if (c==0) c=c2;
        if ((c & 1)!=0)
        {
            y=(int) (y1+((y2-y1)*(-x1)/(x2-x1)));
            x=0;
        }
        else if ((c & 2)!=0)
        {
            y=(int) (y1+((y2-y1)*(MAXX-1-x1)/(x2-x1)));
            x=MAXX-1;
        }
        else if ((c & 8)!=0)
        {
            x=(int) (x1+((x2-x1)*(MAXY-1-y1)/(y2-y1)));
            y=MAXY-1;
        }
        else if ((c & 4)!=0)
        {
            x=(int) (x1+((x2-x1)*(-y1)/(y2-y1)));
            y=0;
        }
        if (c==c1)
        {
            x1=x;y1=y;
            fastcode(x1,y1,c1);
        }
        else
        {
            x2=x;y2=y;
            fastcode(x2,y2,c2);
        }
    }
    GrVertex A,B;

    A.x = (LONG)x1; A.y = (LONG)y1; 
    B.x = (LONG)x2; B.y = (LONG)y2;

    grConstantColorValue(mat->GetR() | (mat->GetG()<<8) | (mat->GetB()<<16));
    grDrawLine(&A, &B);
L10:;
}

void mvgalineDepth( LONG x1, LONG y1, LONG z1,
		    LONG x2, LONG y2, LONG z2,
		    Material *mat)
{
    int c,c1,c2;
    int x,y;
    
    fastcode(x1,y1,c1);
    fastcode(x2,y2,c2);
    while ((c1!=0) || (c2!=0)) {
        if ((c1 & c2)!=0) goto L10;
        c=c1;
        if (c==0) c=c2;
        if ((c & 1)!=0)
        {
            y=(int) (y1+((y2-y1)*(-x1)/(x2-x1)));
            x=0;
        }
        else if ((c & 2)!=0)
        {
            y=(int) (y1+((y2-y1)*(MAXX-1-x1)/(x2-x1)));
            x=MAXX-1;
        }
        else if ((c & 8)!=0)
        {
            x=(int) (x1+((x2-x1)*(MAXY-1-y1)/(y2-y1)));
            y=MAXY-1;
        }
        else if ((c & 4)!=0)
        {
            x=(int) (x1+((x2-x1)*(-y1)/(y2-y1)));
            y=0;
        }
        if (c==c1)
        {
            x1=x;y1=y;
            fastcode(x1,y1,c1);
        }
        else
        {
            x2=x;y2=y;
            fastcode(x2,y2,c2);
        }
    }
    GrVertex A,B;

    A.x = x1; A.y = y1; A.oow=((FLOAT)1.0)/z1;
    B.x = x2; B.y = y2; B.oow=((FLOAT)1.0)/z2;

    A.a = z1/FADE_SPEED;
    B.a = z2/FADE_SPEED;

    if (A.a<0) A.a=0;
    if (A.a>255) A.a=255;
    if (B.a<0) B.a=0;
    if (B.a>255) B.a=255;

    grConstantColorValue(mat->GetR() | (mat->GetG()<<8) | (mat->GetB()<<16));
    grAADrawLine(&A, &B);
    L10:;
}
