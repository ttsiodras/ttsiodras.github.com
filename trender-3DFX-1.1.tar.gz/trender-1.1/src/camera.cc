/*
 *  trender - 3D Studio .ASC files realtime renderer
 *  Copyright (C) 1999  Thanassis Tsiodras (ttsiod@softlab.ntua.gr)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <math.h>
#include "3dtypes.h"
#include "camera.h"

#ifdef ONE_CAMERA

FLOAT Camera::fEyeX, Camera::fEyeY, Camera::fEyeZ;
FLOAT Camera::fToX, Camera::fToY, Camera::fToZ;
FLOAT Camera::m00, Camera::m01, Camera::m02, Camera::m03;
FLOAT Camera::m10, Camera::m11, Camera::m12, Camera::m13;
FLOAT Camera::m20, Camera::m21, Camera::m22, Camera::m23;

#endif

void Camera::upat(FLOAT vx, FLOAT vy, FLOAT vz,
		  FLOAT px, FLOAT py, FLOAT pz,
		  FLOAT ux, FLOAT uy, FLOAT uz)
{
    FLOAT forward[3], side[3], up[3];

    forward[XX] = px - vx;
    forward[YY] = py - vy;
    forward[ZZ] = pz - vz;

    /* temporarily use view-up to hold world-up */
    up[XX] = ux;
    up[YY] = uy;
    up[ZZ] = uz;

    normalize(forward);

    /* generate the vector side from the
     * 2 vectors view forward and world up
     */
    cross(side, forward, up);
    normalize(side);

    /* generate the view up vector from
     * the 2 vectors view forward and view side
     */
    cross(up, side, forward);
    normalize(up);

    m00 = up[XX];
    m01 = up[YY];
    m02 = up[ZZ];

    m10 = side[XX];
    m11 = side[YY];
    m12 = side[ZZ];

    m20 = forward[XX];
    m21 = forward[YY];
    m22 = forward[ZZ];

/*    translate(-vx, -vy, -vz);*/
    m03 = -vx*up[XX]      - vy*up[YY]      - vz*up[ZZ];
    m13 = -vx*side[XX]    - vy*side[YY]    - vz*side[ZZ];
    m23 = -vx*forward[XX] - vy*forward[YY] - vz*forward[ZZ];
}

/*
 *   generate a normalized vector of length 1.0
 */
void Camera::normalize(FLOAT *v)
{
    FLOAT r;

    r = sqrt( v[XX]*v[XX] + v[YY]*v[YY] + v[ZZ]*v[ZZ] );
    if (!r) return;

    v[XX] /= r;
    v[YY] /= r;
    v[ZZ] /= r;
}

/*
 *   make a cross product of the two vectors passed in via v1 and v2,
 *   and return the resulting perpendicular-to-both vector in result
 */
void Camera::cross(FLOAT *result, FLOAT *v1, FLOAT *v2)
{
    result[XX] = v1[YY]*v2[ZZ] - v1[ZZ]*v2[YY];
    result[YY] = v1[ZZ]*v2[XX] - v1[XX]*v2[ZZ];
    result[ZZ] = v1[XX]*v2[YY] - v1[YY]*v2[XX];
}

void Camera::Set(   FLOAT fX, FLOAT fY, FLOAT fZ,
		    FLOAT fXX, FLOAT fYY, FLOAT fZZ)
{
    fEyeX = fX;
    fEyeY = fY;
    fEyeZ = fZ;
    
    fToX = fXX;
    fToY = fYY;
    fToZ = fZZ;
    
    upat(fEyeX, fEyeY, fEyeZ, fToX, fToY, fToZ, 0.0, 0.0, 1.0);
}
