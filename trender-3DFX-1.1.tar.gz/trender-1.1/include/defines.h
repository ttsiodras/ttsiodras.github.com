/*
 *  trender - 3D Studio .ASC files realtime renderer
 *  Copyright (C) 1999  Thanassis Tsiodras (ttsiod@softlab.ntua.gr)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef __GOURAUD_INCLUDED__
#define __GOURAUD_INCLUDED__

#include "types.h"
#include "vgalib.h"

// Rendering window size
#define MAXX 640
#define MAXY 480

#define CLIPBOTTOM MAXY
#define CLIPTOP 0
#define SCANSIZ MAXX

// Field of view
#define FOV 512.0

// View cone bottom distance
#define ZCLIP 2.0

#define M_2PI 2*3.1415926

// Baackground color - Sky Blue
#define BACKGROUND 0x007f3f3f

// Fog decaying speed
#define FADE_SPEED 10

#endif
