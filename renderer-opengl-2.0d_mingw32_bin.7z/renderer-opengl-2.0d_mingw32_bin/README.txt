WHAT IS THIS?
=============

This package contains the Windows binary of my OpenGL renderer
(http://ttsiodras.googlepages.com/trimesh.html). It has been created 
through cross-compilation of the renderer-OpenGL source code 
using MingW, the GNU cross compiler for Windows.

Put simply: this program allows interactive visualization of 
3D triangle meshes. This is done in point, wireframe, gouraud
and true phong shading with ambient occlusion.

Notice that the Phong shading mode is real-phong-shading, done through
vertex and fragment shaders. The shaders were based on various sources 
scattered on the Web (no, I didn't read any book). I also used VBO
to offload all the rendering to the HW - a 70$ Radeon 4670 can
draw 100 million phong shaded triangles per second with my renderer.

RUNNING
=======

Run demo.bat, or equivalently

	final3d.exe trainColor.ply

or try...

	final3d.exe horse.ply

These are some of the available objects.  Have a look at the other 
objects as well.

To navigate,

- R toggles autospin.
- Fly around with the cursor keys,A,Z and rotate the light with W. 
- SPACE changes the rendering mode (points - lines - gouraud - phong).
- S,F,E and D are 'strafe' left/right/up/down.
- ESC quits. 

Thanassis Tsiodras, Dr.-Ing.
ttsiod_at-no-spam_thanks-softlab_ntua-gr
