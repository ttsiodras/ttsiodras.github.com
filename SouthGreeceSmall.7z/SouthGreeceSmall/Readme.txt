A real-time flight over South Greece
====================================

Version 1.4
-----------
Just run 'small.bat', and fly around with the cursor keys.

Keys:
- 'A' and 'Z' move forward and backward
- Cursor keys change the direction you look
- SPACE changes the rendering mode (points -> lines -> triangles).
- ESC quits.

The small map has a grid accuracy of 4km.
You can also download the 2km version at my website:
http://www.softlab.ntua.gr/~ttsiod/

This is a Win32 demonstration of the OpenGL implementation of Trender,
my simple triangle rendering engine.

The '.tri' models are produced from the GTOPO30 data (available on the web).

Thanassis Tsiodras, Dr.-Ing.
ttsiod@softlab.ntua.gr
