/***************************************************************************
 *  HeapCheck - a heap debugging library
 *  Copyright (C) 2001  Thanassis Tsiodras (ttsiod@softlab.ntua.gr)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **************************************************************************
 *
 * HeapCheck 1.34
 * ==============
 *
 * A simple debugging allocator, designed to help heap bug-hunting.
 * Like most debugging heap allocators, it helps you find memory leaks.
 * It also helps you where others can't: in catching invalid accesses.
 * It uses the paging system to create inaccessible pages by the side
 * of your normal allocations. This way, accesses outside the heap-
 * allocated space cause an exception (even READ accesses). This is much 
 * better than heap debugging done with:
 *
 * 1. Visual C++ 6.0 Runtime Heap Debugging:
 *    This only checks for heap corruption (i.e. only WRITINGS outside 
 *    the allocations) and even then, it only catches writings in the
 *    NO_MANS_LAND_SIZE (default:4 bytes) on either side of the blocks.
 *    The detection of these errors is done whenever the user (or the system)
 *    calls _CrtCheckMemory(). HeapCheck catches READ accesses as well, 
 *    at the EXACT place they are made, and in a much larger
 *    block (a page in i386 systems is 4096 bytes).
 *
 * 2. BoundsChecker:
 *    This is a very good debugging tool, capable of catching almost 
 *    every bug. However, in order to perform all these checks, a lot
 *    of CPU cycles are used, especially in instrumentation mode and 
 *    maximum memory checking (some programs won't work correctly when 
 *    they run so slowly, e.g. protocol stacks). HeapCheck catches only 
 *    heap-related errors, but it uses the paging hardware to do the 
 *    checking. The net result is that the HeapCheck debug versions of 
 *    programs run at almost the same speed as normal debug versions.
 *
 * I hope (but can't guarantee) that it will help you in your heap
 * bug hunting. It has definitely helped me with my projects.
 * Many thanks for the original idea go to the creator of UNIX's
 * Electric Fence, Bruce Perens. Oh, and make sure you use the 
 * correct (Win2000) versions of the debugging libraries. I used:
 *
 *    dbghelp.dll   : 5.0.2195.1
 *    imagehlp.dll  : 5.0.2195.1
 *
 * Maybe SymGetLineFromAddr works with other combinations, but I used
 * these successfully under both NT 4.0sp6 and Win2000.
 *
 * Happy coding!
 * Thanassis Tsiodras
 * ttsiod@softlab.ntua.gr
 *
 **************************************************************************
 */

/* 
 * Remember, all of this code gets called only in _DEBUG builds!
 * Check swaps.h to see why...
 */

/* 
 * NOTE: Currently this does seem to have problems with ATL/WTL code
 * Mike Diack
 */

#ifdef _DEBUG

/*
 * This means that your project doesn't have to manually include imagehlp.lib in it's linkage
 * settings, thus making heapcheck more of a seamless "drop in" for your projects.
 */
#pragma comment( lib, "imagehlp" )

/* Enable use of _ASSERTE and rpcasync.h at warning level 4 */
#pragma warning( disable : 4127 )
#pragma warning( disable : 4115 )

#include <windows.h>
#include <crtdbg.h>
#include <imagehlp.h>

/* Include prototypes for HeapCheck functions */
#include "HeapCheckPrototypes.h"

/*
 * It is possible to write code that bypasses the allocation mechanisms of  
 * the library, and allocates from the standard VC-heap. An example inside 
 * the runtime library is the use of an enhanced 'new' operator in 
 * iostrini.cpp (line 21) and cerrinit.cpp (line 21) where _new_crt is used.
 * _new_crt maps through a #define to a 'new' operator that takes extra
 * parameters. HeapCheck can't catch this call, so when the time comes for 
 * the deletion of these blocks, the library's delete operator doesn't find 
 * them in it's tables. It is capable though to understand that these are
 * VC-heap blocks, through the use of _CrtIsValidHeapPointer.
 *
 * If you #define NO_VC_HEAP_ERRS, the library won't complain for such 
 * situations. This is the default, but if you use inside your code direct 
 * calls to _malloc_dbg, _calloc_dbg, etc, you should disable this.
 */

#define NO_VC_HEAP_ERRS

/*
 * Modify this for Alpha, PowerPC, etc. It is the page size used by
 * the virtual memory hardware. For Intel architectures, this is 4096
 * bytes. For others, place a breakpoint in the call to HeapCheckStartup's
 * GetSystemInfo, and read the 'dwPageSize' field of the 'si' variable.
 */

#define PAGE_SIZE     4096

/*
 * Total concurrent allocations possible. If your program needs more,
 * you'll get an assertion telling you to increase this.
 */

#define MAX_ALLOCATIONS     16384

/*
 * Total heap available to the application. If your program needs more,
 * you'll get an assertion telling you to increase this.
 * This implies (MAX_ALLOCATABLE_BLOCK / PAGE_SIZE) pages of heap space.
 */

#define MAX_ALLOCATABLE_BLOCK   (8 * 1048576)

/*
 * Max depth of call stack looked up when our functions are called
 */

#define MAX_STACK_DEPTH     60

/*
 * Define PRINT_NUMERIC_EIP to get stack traces that boldly go
 * where no imagehlp.dll has gone before... Hope you have SoftIce...
 */

/* #define PRINT_NUMERIC_EIP */

/*
 * Variables
 */

/* This is data filled in by the OS at startup and is used via some ASSERT checks */
/* to check that heapcheck is using the memory allocation API in a way that is in */
/* line with the OS itself....................................................... */
static DWORD dwAllocationGranularity = 0;

/* This points to an untouchable area of committed memory of size MAX_ALLOCATABLE_BLOCK bytes */
/* which provides our "protected heap" ...................................................... */
static PCHAR pMemoryBase = NULL;

/* How many pages have we allocated for the whole heap (doesn't change once initialised) */
static DWORD dwTotalPages = 0;

/* How many free pages are available in the memory heap (changes) */
static DWORD dwFreePages = 0;

/* Each one of these represents an allocated area of memory (i.e. a malloc, */
/* calloc, new etc) which may be of pretty much arbitrary size              */
static struct tag_allocations
{
  /* 0 indicates that the memory slot is in use, non zero indicates otherwise, i.e. memory is available */
  DWORD isFree;
  
  /* This is a pointer to the actual memory available for the application to use - effectively the result of malloc */
  PCHAR pData;
  
  /* The number of (PAGE_SIZE) pages required to store the data (dwLength) plus one guard page */
  DWORD dwPages;

  /* How big is the memory allocation (bytes) */
  DWORD dwLength;

  /* This as far as I can tell are the addresses of the function calls leading to the allocation         */
  /* This represents the call stack leading to the allocation (EIP is the Intel x86 instruction pointer) */
  DWORD EIPs[MAX_STACK_DEPTH];
} allocations[MAX_ALLOCATIONS];

/*
 * Set of flags (1 per page) for all of the allocatable heap for the application.
 * Value of 0 indicates that the page is free (not in use)
 * Value of 1 indicates that the page is in use.
 */
static BYTE pagesState[MAX_ALLOCATABLE_BLOCK / PAGE_SIZE];

/* This indicates a peak figure for the memory allocated at any time (changes) */
static DWORD dwTotalPeakMemory = 0;

/* This indicates at a moment in time what memory in total is currently allocated (changes) */
static DWORD dwTotalAllocated = 0;

/* The critical section for ensuring we handle threading correctly */
static CRITICAL_SECTION section;

/*
 * Function prototypes.
 */

/*
 * Weird hack, in order to support 5 and 6 argument passing to _CrtDbgReport.
 * Unforunately, with VC 5.0/6.0, RPT macros go up until _RPT4!
 */

/*
 * These are our own implementations of _RPT5 and _RPT6 for more flexibility
 */


#ifndef _RPT5
#define _RPT5(rptno, msg, arg1, arg2, arg3, arg4, arg5) \
  do { if ((1 == _CrtDbgReport(rptno, NULL, 0, NULL, msg, arg1, arg2, arg3, arg4, arg5))) \
  _CrtDbgBreak(); } while (0)
#endif

#ifndef _RPT6
#define _RPT6(rptno, msg, arg1, arg2, arg3, arg4, arg5, arg6) \
  do { if ((1 == _CrtDbgReport(rptno, NULL, 0, NULL, msg, arg1, arg2, arg3, arg4, arg5, arg6))) \
  _CrtDbgBreak(); } while (0)
#endif

/* Initialisation function */
static void HeapCheckStartup(void);

/* Shutdown function */
static void HeapCheckShutDown(void);

/* These functions (FindConsecutiveFreePagesSimple and GetSize) are currently unused */
#ifdef ACTIVATE_UNREFERENCED_CODE

/*
 * Simple allocator of pages that never frees. 
 * NOTE: Currently this is not used.
 */
static void* FindConsecutiveFreePagesSimple(DWORD dwPages)
{
  (void) dwPages;
  return pMemoryBase + PAGE_SIZE * (dwTotalPages - dwFreePages);
}

/*
 * Utility function for VC-heap blocks.
 * Should be using binary search, but hey...I'm lazy.
 *
 * NOT TESTED YET - Who cares about VC-blocks?
 * NOTE: Currently this is not used.
 */

static DWORD GetSize(PVOID pData)
{
  /* Search for block length.... - this corresponds to the size of the block pointed to by pData */
  DWORD dwTest = 0;

  /* Scan through asking the C runtime if the memory block pData was a valid block of size dwTest */
  /* (this could potentially take a long time) */
  for (dwTest = 0; dwTest < MAX_ALLOCATABLE_BLOCK; dwTest++)
  {
    /* If it was a valid block of that size, return it */
    if (_CrtIsMemoryBlock(pData, dwTest, NULL, NULL, NULL))
    {
      break;
    }
  }

  /* Somethings gone wrong if we take this long... */
  if (dwTest == MAX_ALLOCATABLE_BLOCK)
  {
    /* So return an error code */
    return ((DWORD) - 1);
  }
  else
  {
    /* Return the size of the allocated block otherwise */
    return dwTest;
  }
}

#endif /* ACTIVATE_UNREFERENCED_CODE */


/*
 * Page allocator that searches for free pages.
 * Can be improved with better algorithms, but it's good enough for
 * most projects...
 */

/* Find an allocation of 'dwPages' consecutive free pages of memory on the heap */
static void* FindConsecutiveFreePages(DWORD dwPages)
{
  /* Iterator for scanning through the pages */
  DWORD i = 0;

  /* This is the (returned) pointer to the free page start */
  PVOID pv = NULL;

  /* Scan through the map of pages... */
  for (i = 0; i < sizeof(pagesState); i++)
  {
    /* Free page ? */
    if (!pagesState[i])
    {
      /* Found a free page. Make sure there's enough free pages after it... */
      PVOID test = NULL;

      /*
       * If you land here after an assertion, stop debugging
       * and increase MAX_ALLOCATABLE_BLOCK, since we've gone off the end of 
       * the map of allocated pages of memory
       */
      _ASSERTE((i + dwPages - 1) < sizeof(pagesState));

      /*
       * Search for used-up page in our searching range... 
       * by looking for a 1 in our "page in use" array, if we find a 1, then the
       * pages are not consecutive and free.
       */

      test = memchr(&pagesState[i], 1, dwPages);

      /* All pages in the consecutive range we looked at were free */
      if (test == NULL)
      {
        /* We found enough pages. */
        break;
      }
    }
  }

  /*
   * If you land here after an assertion 'Retry', stop debugging
   * and increase MAX_ALLOCATABLE_BLOCK, because we've gone off the limits
   * of the block of memory we've allocated.
   */
  _ASSERTE(i < sizeof(pagesState));

  /* Set 1 to these pages's slots to reflect NON-FREE state, i.e. that we've now grabbed them */
  FillMemory(&pagesState[i], dwPages, 1);

  /* Return a pointer to our newly allocated memory */
  pv = pMemoryBase + i * PAGE_SIZE;
  return pv;
}

/* This function receives a pointer to an array of EIP's (see the allocations structure) */
/* The array should normally be 0 terminated ........................................... */
/* Looking at: http://www.unixwiz.net/techtips/win32-callconv-asm.html will help clear up whats going on    */
static void FillCallStack(DWORD EIPs[])
{
  /* This corresponds to the stack frame base pointer */
  DWORD LevelOneFrame = 0;

  DWORD dwFrame = 0;

  /* On entry - find out what called this function */
  __asm
  {
    /* Store eax, ebx */
    push eax  
    push ebx

    /* Get the stack base pointer from the caller's stack into eax*/
    mov eax, [ebp]   /* return to the frame of the caller */

    /* Now store this frame data */
    mov LevelOneFrame, eax

    /* Restore the register states */
    pop ebx
    pop eax
  }    

  /* Do forever */
  for (; ;)
  {
    /* This is the instruction pointer for the call stacks */
    DWORD _eip = 0;

    /* Have we got access to 8 bytes at address LevelOneFrame - if so, break out of the loop */
    if (IsBadReadPtr((VOID *) LevelOneFrame, 8))
    {
      /* If not, quit */
      break;
    }

    /* Was the LevelOneFrame address not on a 4 byte boundary - if so break out of the loop */
    /* (this shouldn't normally happen until we reach the end of things) */
    if (LevelOneFrame & 3)
    {
      /* Not on a 4 byte boundary - something odd here, so quit */
      break;
    }

    /* See: http://www.unixwiz.net/techtips/win32-callconv-asm.html */
    /* Find the instruction pointer that made the call */
    _eip = ((PULONG) LevelOneFrame)[1];

    /* If we hit a NULL pointer break */
    if (!_eip)
    {
      break;
    }

    /* If you end up in this assertion, stop debugging and re-compile */
    /* with an increased value for the MAX_STACK_DEPTH constant.      */
    _ASSERTE(dwFrame < MAX_STACK_DEPTH);

    /* Record the EIP */
    EIPs[dwFrame++] = _eip;

    /* Now, continue the trace by setting the stack frame base pointer to the previous caller's */
    /* base pointer. See: http://www.unixwiz.net/techtips/win32-callconv-asm.html for details   */
    LevelOneFrame = ((PULONG) LevelOneFrame)[0];
  }

  /* Ensure we terminate the list of EIPs (the callstack) */
  EIPs[dwFrame] = 0;
}

/* This function traces the call stack to find out what has called the current function */
/* Looking at: http://www.unixwiz.net/techtips/win32-callconv-asm.html will help clear up whats going on */
static void PrintCaller()
{
  DWORD LevelOneFrame = 0;
  IMAGEHLP_LINE dbgLine;
  DWORD dwTemp = 0;
  HANDLE hProcess = GetCurrentProcess();

  /* On entry - find out what called this function */
  __asm
  {
    /* Store the old eax, ebx */
    push eax  
    push ebx

    /* Get the stack base pointer from the caller's stack */
    mov eax, [ebp]   /* return to the frame of the caller */

    /* Now get that address into our LevelOneFrame variable */
    mov LevelOneFrame, eax

    /* Restore eax, ebx */
    pop ebx
    pop eax
  }    

  for (; ;)
  {
    DWORD _eip;

    /* Check we can read all of the memory (8 bytes) at address LevelOneFrame */
    if (IsBadReadPtr((VOID *) LevelOneFrame, 8))
    {
      /* We failed to be able to read it */
      break;
    }

    /* Is the address not aligned on a 4 byte boundary? */
    if (LevelOneFrame & 3)
    {
      /* If so, something is odd, so quit */
      break;
    }

    /* This is the previous function (the caller's) instruction pointer */
    /* See http://www.unixwiz.net/techtips/win32-callconv-asm.html for details of all this */
    _eip = ((PULONG) LevelOneFrame)[1];
    if (!_eip)
    {
      /* Was it a NULL pointer - if so something is odd */
      break;
    }

    /* Prepare the IMAGEHLP_LINE structure */
    ZeroMemory(&dbgLine, sizeof(IMAGEHLP_LINE));
    dbgLine.SizeOfStruct = sizeof(IMAGEHLP_LINE);

    /* Look up the line, file etc corresponding to _eip */
    if (!SymGetLineFromAddr(hProcess, _eip, &dwTemp, &dbgLine))
    {
      /* If we didn't look it up OK - just dump the eip */
      _RPT1(_CRT_WARN, "Called from EIP = %x\n", _eip);
      break;
    }
    else
    {
      /* If we did find out the details OK, then dump  */
      /* the details of the line corresponding to _eip */
      _RPT3(_CRT_WARN, "\tCalled from line %d(+%d bytes) of %s\n",dbgLine.LineNumber, dwTemp, dbgLine.FileName);
    }

    /* Now move back to the previous caller's stack frame base pointer */
    LevelOneFrame = ((PULONG) LevelOneFrame)[0];
  }
}

/*
 * Post-allocation fence versions of malloc, calloc, realloc and free 
 */

/* Allocate blockSize bytes and return a pointer to the memory */
void* HeapCheckPostFenceMalloc(size_t blockSize)
{
  /* Which slot in the allocation structure are we going to use */
  DWORD dwSlot;

  /* Required number of pages - based on the blockSize to allocate */
  DWORD dwPages;

  /* This seems to be a placeholder for the memory protection system */
  DWORD dwOldProtection;

  /* This is the result of the malloc call - i.e. the returned pointer to free memory */
  PCHAR data = NULL;

  /* */
  BOOL bResult = FALSE;

  /* */
  LPVOID lpvResult = NULL;

  /* This is simply a "once off" flag to ensure that the first time */
  /* we allocate memory that we do initialise the heap library      */
  static DWORD dwFirstTime = 1;

  /* On the first allocation, call HeapCheckStartup to initialise this library */
  if (dwFirstTime)
  {
    dwFirstTime = 0;
    HeapCheckStartup();
  }

  /* If we try to allocate 0 bytes, return NULL */
  /* The results are actually not defined by the standard - so raise a warning           */
  /* and point out where the call was made from - i.e. what tried to make the allocation */
  if (blockSize == 0)
  {
    _RPT0(_CRT_WARN, "\n### WARNING ### Trying to make a malloc claim of 0 bytes is technically undefined\n");
    _RPT0(_CRT_WARN, "Call stack follows:\n");
    PrintCaller ();
    return NULL;
  }

  /* Claim a critical section for threading safety etc. */
  EnterCriticalSection(&section);

  /* Look for an allocation slot to record the details for the memory we're going to try to malloc */
  for (dwSlot = 0; dwSlot < MAX_ALLOCATIONS; dwSlot++)
  {
    /* Found one? If so mark it */
    if (allocations[dwSlot].isFree)
    {
      allocations[dwSlot].isFree = 0;
      break;
    }
  }

  /* If you end up in this assertion, stop debugging and re-compile */
  /* with an increased value for the MAX_ALLOCATIONS constant.      */
  _ASSERTE(dwSlot != MAX_ALLOCATIONS);

  /* Calculate number of required pages - one extra per page - i.e. enough */
  /* pages that you'd normally require plus one extra (the guard page)     */
  dwPages = ((blockSize - 1) / PAGE_SIZE) + 2;

  /* _RPT2(_CRT_WARN, "Requested %7d bytes, granted %2d pages\n", blockSize, dwPages); */

  /* Make sure we have enough room */
  if (dwFreePages < dwPages)
  {
    _RPT1(_CRT_WARN, "Your application requires more free memory...\n""Increase MAX_ALLOCATABLE_BLOCK in %s.",  __FILE__);
    _ASSERTE(dwFreePages >= dwPages);
  }

  /* OK, now try to find some pages of memory to make the allocation to */
  /* Return a pointer within the memory based at pvMemoryBase           */
  data = FindConsecutiveFreePages(dwPages);

  /* OK, now make data-pages available... */
  /* At memory address data. NOTE: We don't include the guard page - hence the subtraction of -1 from dwPages */
  /* Commit the memory by MEM_COMMIT and make it read/writeable */
  lpvResult = VirtualAlloc((LPVOID) data, (dwPages - 1) * PAGE_SIZE, MEM_COMMIT, PAGE_READWRITE);
  _ASSERTE(lpvResult != NULL);

  /* Now set the protection on the commited memory */
  VirtualProtect((LPVOID) data, (dwPages - 1) * PAGE_SIZE, PAGE_READWRITE, &dwOldProtection);

  /* Now decommit the guard page - note the pointer arithmetic */
  /* Touching it for reads or writes will cause a GPF */
  bResult = VirtualFree((LPVOID) (data + (dwPages - 1) * PAGE_SIZE), PAGE_SIZE, MEM_DECOMMIT);
  _ASSERTE(bResult == TRUE);

  /* This is quite clever - we now move the data pointer up so that the 1st */
  /* byte after our block will be in the guardpage we've just decommited    */
  /* This is the very crux of the memory protection ....................... */
  data = data + (PAGE_SIZE - (blockSize % PAGE_SIZE)) % PAGE_SIZE;

  /* Take account of our memory allocation */
  dwFreePages = dwFreePages - dwPages;

  /* Update the data structure for this allocation with the memory that is to  */
  /* be used, the number of pages allocated, and the number of bytes allocated */
  allocations[dwSlot].pData = data;
  allocations[dwSlot].dwPages = dwPages;
  allocations[dwSlot].dwLength = blockSize;

  /* Record what made the call to malloc */
  FillCallStack(allocations[dwSlot].EIPs);

  /* Cause problems to users who think malloc zeroes block memory... */
  /* NB This is necessary, since VirtualAlloc (above) zeroes it */
  FillMemory(data, blockSize, 0xCD);

  /* Record how much memory we've allocated */
  dwTotalAllocated = dwTotalAllocated + blockSize;

  /* If we've exceeded the current peak allocation, take note of this */
  if (dwTotalPeakMemory < dwTotalAllocated)
  {
    dwTotalPeakMemory = dwTotalAllocated;
  }

  /* Release the critical section */
  LeaveCriticalSection(&section);

  return (void *) data;
}

/* Heapchecking version of calloc */
void* HeapCheckPostFenceCalloc(size_t blockSize)
{
  /* Grab the memory via malloc */
  PVOID* data = HeapCheckPostFenceMalloc(blockSize);

  /* Clear it */
  if (data != NULL)
  {
    FillMemory(data, blockSize, 0);
  }
  return data;
}

/* Try to do a realloc on ptr making it size bytes */
/* NB. Mike Diack has added a bugfix to enable the code to handle realloc (ptr, 0) correctly */
void* HeapCheckPostFenceRealloc(void* ptr, size_t size)
{
  /* This is the newly (reallocated) memory */
  void* tmpData = NULL;

  /* This is used to look through the list of allocations */
  DWORD dw = 0;

  /* Bugfix/Enhancement to the original code */
  /* If size is 0 and a valid pointer is given */
  /* then realloc behaves like free .......... */
  if (ptr != NULL)
  {
    if (size == 0)
    {
      _RPT0(_CRT_WARN,"\n### WARNING ### Realloc is being used to free memory (size = 0) - which is unusual...\n");
      PrintCaller();
      HeapCheckPostFenceFree (ptr);
      return (NULL);
    }
  }

  /* Lock for thread safety */
  EnterCriticalSection(&section);

  /* Look through to see if we can find the memory already */
  for (dw = 0; dw < MAX_ALLOCATIONS; dw++)
  {
    /* If the memory is in use */
    if (!allocations[dw].isFree)
    {
      /* Is this allocation corresponding to the pointer passed in */
      if (allocations[dw].pData == ptr)
      {
          break;
      }
    }
  }

  /* Did we not find our allocation */
  if (dw == MAX_ALLOCATIONS)
  {
    _RPT0(_CRT_WARN,
      "### ERROR ### Attempt to realloc unallocated block!...\n");
    PrintCaller();
    _ASSERTE(dw != MAX_ALLOCATIONS);
  }

  /* Unlock for thread safety */
  LeaveCriticalSection(&section);

  /* Try to claim the new memory block */
  tmpData = HeapCheckPostFenceMalloc(size);
  
  /* Couldn't allocate it - return NULL - our original memory is still available */
  if (!tmpData)
  {
    return NULL;
  }

  /* All is well - we've got the new memory - so do the copying */

  /* Are we reallocing a smaller buffer than before? */
  if (size < allocations[dw].dwLength)
  {
    /* If so just copy to the size of the new buffer */
    CopyMemory(tmpData, allocations[dw].pData, size);
  }
  else
  {
    /* Otherwise copy to fill the size of the new buffer */
    CopyMemory(tmpData, allocations[dw].pData, allocations[dw].dwLength);
  }
  
  /* Release our old pointer */
  HeapCheckPostFenceFree(ptr);

  return tmpData;
}

/* This code implements free */
void HeapCheckPostFenceFree(void* pData)
{
  PCHAR pTmp = (PCHAR) pData;
  DWORD dw = 0;

  /* Lock for thread safety */
  EnterCriticalSection(&section);

  /* Scan the allocation list */
  for (dw = 0; dw < MAX_ALLOCATIONS; dw++)
  {
    /* If the allocation slot is in use */
    if (!allocations[dw].isFree)
    {
      /* If it points to the memory we're trying to free... */
      if (allocations[dw].pData == pData)
      {
        break;
      }
    }
  }

  /* Did we not find the thing we're trying to free */
  if (dw == MAX_ALLOCATIONS)
  {
    /*
     * This is a block not allocated from us...
     * Check first to see if it was allocated from
     * the normal VC heap through any direct calls
     * (brain-dead coding, that is) 
     */

    /* Nonetheless is it valid heap memory? */
    if (_CrtIsValidHeapPointer(pData))
    {

#ifndef NO_VC_HEAP_ERRS

      /* We will raise errors for memory allocated outside of this heapcheck mechanism */
      char* origFileName;
      DWORD origLineNo;
      DWORD origBlockSize;

      /* For that memories block, get the details and show them with a call stack */
      if (_CrtIsMemoryBlock(pData, origBlockSize = GetSize(pData), NULL, &origFileName, &origLineNo))
      {
        _RPT6(_CRT_WARN,"Freeing VC-heap allocated block (%d bytes from line %d of %s)\n",
          origBlockSize, origLineNo, origFileName);
        PrintCaller();
      }
      else
      {
        /* We don't recognise this memory so do a call stack and fire a breakpoint handler up */
        _RPT0(_CRT_WARN, "Freeing unknown VC-heap allocated block\n");
        PrintCaller();
        _CrtDbgBreak();
      }
#endif

    }
    else
    {
      /* The memory pointer is bogus, so do a call stack and fire up a breakpoint */
      _RPT0(_CRT_WARN,"### ERROR ### Attempt to free unallocated block!... \n");
      PrintCaller();
      _CrtDbgBreak();
    }

    /* Release the thread lock */
    LeaveCriticalSection(&section);
    return;
  }

  /* Make data pages inaccessible, since they are freed! */

  /* Set pTmp to point to the beginning of the page that the memory allocation began in */
  pTmp = pTmp - (((DWORD) pTmp) % PAGE_SIZE);
  
  /* Now free the memory */
  VirtualFree(pTmp, (allocations[dw].dwPages - 1) * PAGE_SIZE, MEM_DECOMMIT);

  /* Set these pages to be marked as 'available' again */
  ZeroMemory(&pagesState[(pTmp - pMemoryBase) / PAGE_SIZE], allocations[dw].dwPages);

  /* Restore the freed memory count */
  dwFreePages = dwFreePages + allocations[dw].dwPages;

  /* The current amount of allocated memory also drops accordingly */
  dwTotalAllocated -= allocations[dw].dwLength;

  /* Mark the memory slot as free now */
  allocations[dw].isFree = 1;    
  allocations[dw].pData = NULL;
  allocations[dw].dwPages = 0;
  allocations[dw].dwLength = 0;
  allocations[dw].EIPs[0] = 0;

  /* Release the locks again */
  LeaveCriticalSection(&section);
}

/*
 * Pre-allocation fence versions of malloc, calloc, realloc and free
 *
 */

/* A pre-buffer checking version of malloc */
void* HeapCheckPreFenceMalloc(size_t blockSize)
{
  /* Which slot in the allocation structure are we going to use */
  DWORD dwSlot = 0;

  /* How many pages of memory do we need to claim */
  DWORD dwPages = 0;

  /* Used for setting the access rights on the memory */
  DWORD dwOldProtection = 0;

  /* This is the pointer to the malloced memory */
  PCHAR data = NULL;

  /* Flag used to check the results of calling the memory management APIs */
  BOOL bResult = FALSE;

  /* Result of some of the memory allocation API's */
  LPVOID lpvResult = NULL;

  /* Flag to ensure we start the library on the first allocation */ 
  static DWORD dwFirstTime = 1;

  /* On the first invocation, set up the HeapCheck library */
  if (dwFirstTime)
  {
    dwFirstTime = 0;
    HeapCheckStartup();
  }

  /* If we try to allocate 0 bytes, return NULL */
  /* The results are actually not defined by the standard - so raise a warning           */
  /* and point out where the call was made from - i.e. what tried to make the allocation */
  if (blockSize == 0)
  {
    _RPT0(_CRT_WARN, "\n### WARNING ### Trying to make a malloc claim of 0 bytes is technically undefined\n");
    _RPT0(_CRT_WARN, "Call stack follows:\n");
    PrintCaller ();
    return NULL;
  }

  /* Claim a critical section for thread safety */
  EnterCriticalSection(&section);

  /* Find a free allocation slot to use to store the details of this allocation */
  for (dwSlot = 0; dwSlot < MAX_ALLOCATIONS; dwSlot++)
  {
    if (allocations[dwSlot].isFree)
    {
      allocations[dwSlot].isFree = 0;
      break;
    }
  }

  /* If you end up in this assertion, stop debugging and re-compile */
  /* with an increased value for the MAX_ALLOCATIONS constant.      */
  _ASSERTE(dwSlot != MAX_ALLOCATIONS);

  /* Calculate number of required pages - one extra per page - i.e. enough */
  /* pages that you'd normally require plus one extra (the guard page)     */
  dwPages = ((blockSize - 1) / PAGE_SIZE) + 2;

  /* _RPT2(_CRT_WARN, "Requested %7d bytes, granted %2d pages\n", blockSize, dwPages); */

  /* Make sure we have enough room */
  if (dwFreePages < dwPages)
  {
    _RPT1(_CRT_WARN,
      "Your application requires more free memory...\n"
      "Change MAX_ALLOCATABLE_BLOCK in %s.",
      __FILE__);
    _ASSERTE(dwFreePages >= dwPages);
  }

  /* Now try to find some pages of memory to make the allocation to */
  /* Return a pointer to a memory block within the memory based at  */
  /* pvMemoryBase ................................................. */
  /* The first page of this (at data) will be the guard page        */
  data = FindConsecutiveFreePages(dwPages);

  /* OK, now make fence-page untouchable... */
  /* Remember this time it's the page before our memory that we want to make untouchable */
  /* Touching any part of this page (read or write) will result in a GPF ............... */
  bResult = VirtualFree((LPVOID) data, PAGE_SIZE, MEM_DECOMMIT);
  _ASSERTE(bResult == TRUE);

  /* Now make the page after the guardpage available and all of the necessary pages (dwPages - 1) to include our allocation */
  lpvResult = VirtualAlloc((LPVOID) (data + PAGE_SIZE), (dwPages - 1) * PAGE_SIZE, MEM_COMMIT, PAGE_READWRITE);
  _ASSERTE(lpvResult != NULL);    

  /* Set the protection rights on that memory */
  VirtualProtect((LPVOID) (data + PAGE_SIZE), (dwPages - 1) * PAGE_SIZE, PAGE_READWRITE, &dwOldProtection);

  /* Now move data on to point to our real allocation area */
  data = data + PAGE_SIZE;

  /* Take account of the pages that are in use */
  dwFreePages = dwFreePages - dwPages;

  /* Store the details of the allocation */
  allocations[dwSlot].pData = data;
  allocations[dwSlot].dwPages = dwPages;
  allocations[dwSlot].dwLength = blockSize;

  /* Save the call stack */
  FillCallStack(allocations[dwSlot].EIPs);

  /* Cause problems to users who think malloc zeroes block memory... */
  FillMemory(data, blockSize, 0xCD);

  /* Record how much memory is allocated */
  dwTotalAllocated = dwTotalAllocated + blockSize;

  /* Update the peak count of memory if required */
  if (dwTotalPeakMemory < dwTotalAllocated)
  {
    dwTotalPeakMemory = dwTotalAllocated;
  }

  /* Remove the thread locks for safety */
  LeaveCriticalSection(&section);

  /* Return the area that we can read/write to */
  return (void *) data;
}

/* A pre-buffer checking version of calloc */
void* HeapCheckPreFenceCalloc(size_t blockSize)
{
  /* Allocate the memory */
  PVOID* data = HeapCheckPreFenceMalloc(blockSize);
  if (data != NULL)
  {
    /* Clear the memory */
    FillMemory(data, blockSize, 0);
  }

  /* Return a pointer to the memory */
  return data;
}

/* Implement a pre-buffer checking version of realloc */
/* NB. Mike Diack has added a bugfix to enable the code to handle realloc (ptr, 0) correctly */
void* HeapCheckPreFenceRealloc(void* ptr, size_t size)
{
  /* This is a pointer to the newly (reallocated) memory */
  void* tmpData = NULL;

  /* This is used to look through the list of allocations */
  DWORD dw = 0;

  /* Bugfix/Enhancement to the original code */
  /* If size is 0 and a valid pointer is given */
  /* then realloc behaves like free .......... */
  if (ptr != NULL)
  {
    if (size == 0)
    {
      _RPT0(_CRT_WARN,"\n### WARNING ### Realloc is being used to free memory (size = 0) - which is unusual...\n");
      PrintCaller();
      HeapCheckPreFenceFree (ptr);
      return (NULL);
    }
  }

  /* Claim a critical section for thread safety */
  EnterCriticalSection(&section);

  /* Look through the list of allocations */
  for (dw = 0; dw < MAX_ALLOCATIONS; dw++)
  {
    /* If the allocation is in use */
    if (!allocations[dw].isFree)
    {
      /* If the allocation we've found matches the address we're trying to reallocate */
      if (allocations[dw].pData == ptr)
      {
        break;
      }
    }
  }

  /* Check in case we couldn't find a match for that pointer */
  /* If so, dump a call stack */
  if (dw == MAX_ALLOCATIONS)
  {
    _RPT0(_CRT_WARN,"### ERROR ### Attempt to realloc unallocated block!...\n");
    PrintCaller();
    _ASSERTE(dw != MAX_ALLOCATIONS);
  }

  /* Yield the critical section */
  LeaveCriticalSection(&section);

  /* Allocate our new memory block */
  tmpData = HeapCheckPreFenceMalloc(size);

  /* If we couldn't allocate it, return a NULL pointer */
  /* and leave our memory unchanged .................. */
  if (tmpData == NULL)
  {
    return NULL;
  }

  /* Otherwise (success) */

  /* Has the buffer become smaller compared to the old one */
  if (size < allocations[dw].dwLength)
  {
    /* If so, just copy the smaller size */
    CopyMemory(tmpData, allocations[dw].pData, size);
  }
  else
  {
    /* Otherwise, fill the new (bigger/equal sized) buffer */
    CopyMemory(tmpData, allocations[dw].pData, allocations[dw].dwLength);
  }

  /* Give back the original memory */
  HeapCheckPreFenceFree(ptr);

  return tmpData;
}

/* Free the memory pointed to by pData */
void HeapCheckPreFenceFree(void* pData)
{
  /* */
  PCHAR pTmp = NULL;

  /* */
  DWORD dw = 0;

  /* Claim a critical section for thread safety */
  EnterCriticalSection(&section);

  /* Look through our list of allocations */
  for (dw = 0; dw < MAX_ALLOCATIONS; dw++)
  {
    /* If the slot is in use */
    if (!allocations[dw].isFree)
    {
      /* See if the allocation slot matches the data we're trying to free */
      if (allocations[dw].pData == pData)
      {
        break;
      }
    }
  }

  /* See if we didn't manage to find the pointer in our allocation list */
  if (dw == MAX_ALLOCATIONS)
  {
    /*
     * This is a block not allocated from us...
     * Check first to see if it was allocated from
     * the normal VC heap through any direct calls
     * (brain-dead coding, that is)
     */

    /* Nonetheless... Is it valid heap memory ? */
    if (_CrtIsValidHeapPointer(pData))
    {

#ifndef NO_VC_HEAP_ERRS

      /* We will raise errors for memory allocated outside of the heapcheck mechanism */
      char* origFileName;
      DWORD origLineNo;
      DWORD origBlockSize;

      /* Get the details of that memory block allocation and show them with a call stack */
      if (_CrtIsMemoryBlock(pData, origBlockSize = GetSize(pData), NULL, &origFileName, &origLineNo))
      {       
        _RPT6(_CRT_WARN,"Freeing VC-heap allocated block (%d bytes from line %d of %s)\n",origBlockSize, origLineNo, origFileName);
        PrintCaller();
      }
      else
      {
        /* We don't recognise this memory, so dump a call stack and fire up a breakpoint */
        _RPT0(_CRT_WARN, "Freeing unknown VC-heap allocated block\n");      
        PrintCaller();
        _CrtDbgBreak();
      }
#endif
    }
    else
    {
      /* The memory pointer itself is bogus, so dump a call stack and fire up a breakpoint */
      _RPT0(_CRT_WARN,"### ERROR ### Attempt to free unallocated block!... \n");
      PrintCaller();
      _CrtDbgBreak();
    }

    /* Yield the critical section and exit */
    LeaveCriticalSection(&section);
    return;
  }

  /* Otherwise, it looks like one of our pointers... */
  /* So ............................................ */

  /* This will free the data pages that our free'd pointer had malloced */
  /* Make data pages inaccessible, since they are freed! */
  VirtualFree(pData, (allocations[dw].dwPages - 1) * PAGE_SIZE, MEM_DECOMMIT);

  /* Set these pages to 'available' again */
  pTmp = (PCHAR) pData;

  /* Now pTmp points to the start of the guard page that was before the actual memory that was available to the user */
  pTmp = pTmp - PAGE_SIZE;

  /* Now zero all of the pages including the guard pages */
  ZeroMemory(&pagesState[(pTmp - pMemoryBase) / PAGE_SIZE], allocations[dw].dwPages);

  /* Take account of the freed up memory */
  dwFreePages = dwFreePages + allocations[dw].dwPages;

  /* Take account of the total memory now allocated */
  dwTotalAllocated = dwTotalAllocated - allocations[dw].dwLength;

  /* Mark the allocation slot as now free */
  allocations[dw].isFree = 1;    
  allocations[dw].pData = NULL;
  allocations[dw].dwPages = 0;
  allocations[dw].dwLength = 0;
  allocations[dw].EIPs[0] = 0;

  /* Give up the critical section */
  LeaveCriticalSection(&section);
}


/*
 * Startup and shutdown functions
 */

/* This is the library initialisation function and should be called just once */
static void HeapCheckStartup()
{
  /* This holds the system properties for checking */
  /* out the hardware memory management support    */
  SYSTEM_INFO si;

  /* Iterator for resetting some of the data structures */
  DWORD dw;

  /* Holds the path to the executable program we're debugging*/
  CHAR dbgPath[MAX_PATH];

  /* Used to parse the executable programs pathname */
  CHAR * pEnd;

  /* Ensure we load line number information */
  SymSetOptions(SymGetOptions() | SYMOPT_LOAD_LINES);

  /* Try to read the symbols from the path of the (current) .exe file */
  /* by grabbing its full pathname into dbgPath                       */
  if (!GetModuleFileName(NULL, dbgPath, sizeof(dbgPath)))
  {
    /* if we failed to load the .exe's symbols, do your best */
    if (!SymInitialize(GetCurrentProcess(), NULL, TRUE))
    {
      _RPT0(_CRT_WARN,
        "HEAPCHECK: Won't be able to read file/line information...:(\n");
    }
  }
  else
  {
    /* Find the last section of the program's path e.g. \myapp.exe */
    pEnd = strrchr(dbgPath, '\\');
    if (!pEnd)
    {
      /* if we failed, do your best */
      if (!SymInitialize(GetCurrentProcess(), NULL, TRUE))
      {
        _RPT0(_CRT_WARN,
          "HEAPCHECK: Won't be able to read file/line information...:(\n");
      }
    }
    else
    {
      /* 99% probability of success with file/line info...! */

      /* Chop the path to just give the directory containing our .exe */
      *pEnd = '\0';

      /* Now initialise symbols support */
      if (!SymInitialize(GetCurrentProcess(), dbgPath, TRUE))
      {
        _RPT0(_CRT_WARN,
          "HEAPCHECK: Won't be able to read file/line information...:(\n");
      }
    }
  }

  /* Setup the critical section support */
  InitializeCriticalSection(&section);

  /* Now get the system information */
  GetSystemInfo(&si);

  /* Check that our PAGE_SIZE constant is correct */
  _ASSERTE(si.dwPageSize == PAGE_SIZE);

  /* Find out how fine our allocation granularity is (64K by default on XP 32 bit) */
  dwAllocationGranularity = si.dwAllocationGranularity;

  /* Check that the OS can't allocate by default more than we've set the system up to run with */
  _ASSERTE(dwAllocationGranularity <= MAX_ALLOCATABLE_BLOCK);

  /* Commit/reserve MAX_ALLOCATABLE_BLOCK bytes heap space          */
  /* Don't actually allocate it yet, just reserve it                */
  /* Any attempts to read/write or execute from it will cause a GPF */
  /* thanks to the use of the PAGE_NOACCESS flag                    */

  pMemoryBase = (PCHAR) VirtualAlloc(NULL,                    /* Place memory base wherever  */
                                      MAX_ALLOCATABLE_BLOCK,  /* Total heap memory available */
                                      MEM_RESERVE,            /* For now, just reserve it    */
                                      PAGE_NOACCESS);         /* and make it no-touch.       */

  /* Check that the OS gave us this reserved memory slot */
  _ASSERTE(pMemoryBase != NULL);

  /* Now work out how many pages we have available in total */
  dwTotalPages = MAX_ALLOCATABLE_BLOCK / PAGE_SIZE;

  /* Initially this is the number of free pages */
  dwFreePages = dwTotalPages;

  /* Ensure that HeapCheckShutDown is called when our application closes */
  if (atexit(HeapCheckShutDown))
  {
    /* If we can't automatically run the function, prompt the user to add an explicit check */
    _RPT0(_CRT_WARN,
      "### WARNING ### Can't check for memory leaks automatically!\n");
    _RPT0(_CRT_WARN,
      "### WARNING ### Call HeapCheckShutDown at the end of your app,\n");
  }

  /* Mark the allocations structure up as ready to be used */
  for (dw = 0; dw < MAX_ALLOCATIONS; dw++)
  {
    allocations[dw].isFree = 1;
  }

  /* Reset the records to indicate that all pages are initially free */
  ZeroMemory(pagesState, sizeof(pagesState));
}

/* This should be called on shutdown */
static void HeapCheckShutDown()
{
  /* Indicates whether we managed to release the memory that the heapcheck tool commits OK */
  BOOL bSuccess;

  /* This is used to iterate through our list of allocations */
  DWORD dw;

  /* Get a handle to my process (myself) */
  HANDLE hProcess = GetCurrentProcess();

  /* We mustn't be interrupted */
  EnterCriticalSection(&section);

  /* Provide a summary/report of the heap state on exit */

  _RPT0(_CRT_WARN, "\n");
  _RPT0(_CRT_WARN, "##################################\n");
  _RPT0(_CRT_WARN, "#######  HeapCheck report   ######\n");
  _RPT0(_CRT_WARN, "##################################\n\n");

  /* Now look through to see the state of our memory */
  for (dw = 0; dw < MAX_ALLOCATIONS; dw++)
  {
    /* If the memory is marked as being in use still, then we've got a leak */
    if (!allocations[dw].isFree)
    {
      /* We have to use IMAGEHLP.DLL. God help us... */
      IMAGEHLP_LINE dbgLine;

      /* This is the offset within the line of code that corresponds to an EIP */
      DWORD dwTemp = 0;
      
      /* This is used to iterate through the list of EIPs */
      DWORD dwCodePlaces = 0;

      /* List the ammount of memory allocated in that slot */
      _RPT1(_CRT_WARN, "### WARNING ### Memory leak (%d bytes) found... Allocated:\n",allocations[dw].dwLength);

      /* Step through the EIPs attached to each allocation (until we reach a 0 (NULL) entry) */
      while (allocations[dw].EIPs[dwCodePlaces])
      {
        /* Prepare the IMAGEHLP_LINE structure */
        ZeroMemory(&dbgLine, sizeof(IMAGEHLP_LINE));
        dbgLine.SizeOfStruct = sizeof(IMAGEHLP_LINE);

        /* Lookup the line information corresponding to that address */
        if (SymGetLineFromAddr(hProcess,allocations[dw].EIPs[dwCodePlaces], &dwTemp, &dbgLine) == FALSE)
        {
          /* If we couldn't get the line information, dump the EIP instead */
#ifdef PRINT_NUMERIC_EIP
          _RPT1(_CRT_WARN, "\tfrom EIP = %x\n",allocations[dw].EIPs[dwCodePlaces]);
#endif
        }
        else
        {
          /* Otherwise, success, so dump the details of the line and source file corresponding to the EIP */
          _RPT3(_CRT_WARN, "\tfrom line %d(+%d bytes) of %s\n",dbgLine.LineNumber, dwTemp, dbgLine.FileName);
        }

        /* Move onto the next EIP (following the call path/stack) */
        dwCodePlaces++;

        /* Check that we're not trying to trace the call strack too far! */
        /* If you land here after an assertion, stop debugging */
        /* and increase MAX_STACK_DEPTH                        */
        _ASSERTE(dwCodePlaces < MAX_STACK_DEPTH);
      }
    }
  }

  /* Decommit the entire block of size MAX_ALLOCATABLE_BLOCK bytes, based at pMemoryBase */ 
  bSuccess = VirtualFree(pMemoryBase, MAX_ALLOCATABLE_BLOCK, MEM_DECOMMIT);
  _ASSERTE(bSuccess);

  /* Release the entire block. */ 
  if (bSuccess)
  {
    /* pMemoryBase is the base address of the block */
    /* 0 = release the whole block */
    /* MEM_RELEASE means release the pages */
    bSuccess = VirtualFree(pMemoryBase, 0, MEM_RELEASE);
  }

  /* Raise an assertion if something is badly wrong */
  _ASSERTE(bSuccess);

  /* Dump out some stats */
  _RPT1(_CRT_WARN,"HeapCheck Statistics:\n\tMaximum memory allocated = %d\n\n", dwTotalPeakMemory);    

  /* Turn off the enhanced debugging features in the DLL */
  (void) SymCleanup(hProcess);

  /* Yield the critical section and then tidy it */
  LeaveCriticalSection(&section);
  DeleteCriticalSection(&section);
}

#pragma warning( default : 4127 )
#pragma warning( default : 4115 )

#endif
