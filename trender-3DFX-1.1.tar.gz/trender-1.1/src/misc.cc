/*
 *  trender - 3D Studio .ASC files realtime renderer
 *  Copyright (C) 1999  Thanassis Tsiodras (ttsiod@softlab.ntua.gr)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include "misc.h"

#ifdef KEYBOARD_CONTROLLED
#include <vgakeyboard.h>
#endif

#include "glide.h"

LONG readtime()
{
    struct timeval now;
    static LONG firstTime = 1;
    static LONG firstValueSec, firstValueUsec;

    if (firstTime) {
	firstTime = 0;
	gettimeofday(&now, NULL);
	firstValueSec = now.tv_sec;
	firstValueUsec = now.tv_usec;
    }

    gettimeofday(&now, NULL);

    return((now.tv_sec-firstValueSec)*1000 + (now.tv_usec-firstValueUsec)/1000);
}

void panic(char *fmt, ...)
{
    va_list arg;

    va_start(arg, fmt);
    vfprintf(stderr, fmt, arg);
    va_end(arg);

    grGlideShutdown();
#ifdef KEYBOARD_CONTROLLED
    keyboard_close();
#endif
    exit(0);
}

void inform(char *fmt, ...)
{
    va_list arg;

    va_start(arg, fmt);
    vfprintf(stderr, fmt, arg);
    va_end(arg);
}
