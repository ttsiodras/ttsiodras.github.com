/*
 *  trender - 3D Studio .ASC files realtime renderer
 *  Copyright (C) 1999  Thanassis Tsiodras (ttsiod@softlab.ntua.gr)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef __CAMERA_INCLUDED__
#define __CAMERA_INCLUDED__

#define ONE_CAMERA

#include "3dtypes.h"
#include "types.h"

#define XX 0
#define YY 1
#define ZZ 2

class Camera {
    friend class Vertex;
#ifdef ONE_CAMERA
    static FLOAT fEyeX, fEyeY, fEyeZ;
    static FLOAT fToX, fToY, fToZ;
    static FLOAT m00,m01,m02,m03,m10,m11,m12,m13,m20,m21,m22,m23;
#else
    FLOAT fEyeX, fEyeY, fEyeZ;
    FLOAT fToX, fToY, fToZ;
    FLOAT m00,m01,m02,m03,m10,m11,m12,m13,m20,m21,m22,m23;
#endif
    void upat(FLOAT vx, FLOAT vy, FLOAT vz,
	      FLOAT px, FLOAT py, FLOAT pz,
	      FLOAT ux, FLOAT uy, FLOAT uz);
    void normalize(FLOAT *v);
    void cross(FLOAT *result, FLOAT *v1, FLOAT *v2);
public:
    Camera(FLOAT vx, FLOAT vy, FLOAT vz, FLOAT px, FLOAT py, FLOAT pz) {
        Set(vx, vy, vz, px, py, pz);
    }
    void Set(FLOAT vx, FLOAT vy, FLOAT vz, FLOAT px, FLOAT py, FLOAT pz);
    FLOAT GetEyeX() { return fEyeX; }
    FLOAT GetEyeY() { return fEyeY; }
    FLOAT GetEyeZ() { return fEyeZ; }

};

#endif
