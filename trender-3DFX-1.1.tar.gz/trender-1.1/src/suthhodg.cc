/*
 *  trender - 3D Studio .ASC files realtime renderer
 *  Copyright (C) 1999  Thanassis Tsiodras (ttsiod@softlab.ntua.gr)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <stdlib.h>

#include "glide.h"
#include "types.h"
#include "defines.h"
#include "misc.h"

#define x1 (ss->x)
#define y1 (ss->y)
#define oow1 (ss->oow)
#define r1 (ss->r)
#define g1 (ss->g)
#define b1 (ss->b)
#define a1 (ss->a)

#define x2 (pp->x)
#define y2 (pp->y)
#define oow2 (pp->oow)
#define r2 (pp->r)
#define g2 (pp->g)
#define b2 (pp->b)
#define a2 (pp->a)

#define SCALETHEM(dst)			\
dst->oow = oow1 + ratio*(oow2-oow1);	\
dst->r = r1 + ratio*(r2-r1);		\
dst->g = g1 + ratio*(g2-g1);		\
dst->b = b1 + ratio*(b2-b1);		\
dst->a = a1 + ratio*(a2-a1)

#define top_inside(p) ((p)->y >= 0)
void top_intersect(GrVertex *dst, GrVertex *ss, GrVertex *pp) 
{
    if (y2 != y1) {			
	FLOAT ratio = (0-y1)/(y2-y1);	
    	dst->x = x1 + ratio*(x2-x1);  	
	SCALETHEM(dst);			
    }				
    else {
	inform("x1 = %f\n", ss->x);
	inform("y1 = %f\n", ss->y);
	inform("z1 = %f\n", ss->z);
	inform("x2 = %f\n", pp->x);
	inform("y2 = %f\n", pp->y);
	inform("z2 = %f\n", pp->z);
	panic("parallel to top");
    }
    dst->y = 0;				
}

#define bottom_inside(p) ((p)->y < MAXY)
void bottom_intersect(GrVertex *dst, GrVertex *ss, GrVertex *pp)		
{
    if (y2 != y1) {				
	FLOAT ratio = (MAXY-y1)/(y2-y1);	
    	dst->x = x1 + ratio*(x2-x1);  		
	SCALETHEM(dst);				
    }						
    else 				
	panic("parallel to bottom");		
    dst->y = MAXY;				
}

#define left_inside(p) ((p)->x >= 0)
void left_intersect(GrVertex *dst, GrVertex *ss, GrVertex *pp)	
{
    if (x2 != x1) {			
	FLOAT ratio = (0-x1)/(x2-x1);	
    	dst->y = y1 + ratio*(y2-y1);  	
	SCALETHEM(dst);			
    }					
    else 				
	panic("parallel to left");	
    dst->x = 0;				
}

#define right_inside(p) ((p)->x < MAXX)
void right_intersect(GrVertex *dst, GrVertex *ss, GrVertex *pp)		
{
    if (x2 != x1) {				
	FLOAT ratio = (MAXX-x1)/(x2-x1);	
    	dst->y = y1 + ratio*(y2-y1);  		
	SCALETHEM(dst);				
    }						
    else 					
	panic("parallel to right");		
    dst->x = MAXX;				
}

#define CLIP \
    for(i=0, ndest=0; i<nsrc; i++)			\
    {							\
    	p = &src[i];					\
        curr = INSIDE(p);				\
        if(!i) {					\
	    f = p; currf=curr;				\
        } else {					\
            if (curr ^ prev) {				\
                INTERSECT(&dest[ndest],s,p);		\
		ndest++;				\
            }						\
        }						\
        s = p;						\
        if (curr)					\
            dest[ndest++] = *s;				\
        prev = curr;					\
    }							\
    if (currf ^ prev) {					\
	INTERSECT(&dest[ndest],s,f);			\
	ndest++;					\
    }							\
    nsrc = ndest

#define CLIP2 \
    for(i=0, ndest=0; i<nsrc; i++)			\
    {							\
    	p = &dest[i];					\
        curr = INSIDE(p);				\
        if(!i) {					\
	    f = p; currf=curr;				\
        } else {					\
            if (curr ^ prev) {				\
                INTERSECT(&src[ndest],s,p);		\
		ndest++;				\
            }						\
        }						\
        s = p;						\
        if (curr)					\
            src[ndest++] = *s;				\
        prev = curr;					\
    }							\
    if (currf ^ prev) {					\
	INTERSECT(&src[ndest],s,f);			\
	ndest++;					\
    }							\
    nsrc = ndest

void SuthHodgTriangleWithClip(GrVertex *a, GrVertex *b, GrVertex *c)
{
    GrVertex *f, *s, *p;
    int i, prev=0, curr=0, currf=0;
    GrVertex dest[20];
    int ndest;
    GrVertex src[20];
    int nsrc=3;

    src[0] = *a;
    src[1] = *b;
    src[2] = *c;

// Clip top
#undef INSIDE
#undef INTERSECT
#define INSIDE top_inside
#define INTERSECT top_intersect

    CLIP;

// Clip bottom
#undef INSIDE
#undef INTERSECT
#define INSIDE bottom_inside
#define INTERSECT bottom_intersect

    CLIP2;

// Clip left
#undef INSIDE
#undef INTERSECT
#define INSIDE left_inside
#define INTERSECT left_intersect

    CLIP;

// Clip right
#undef INSIDE
#undef INTERSECT
#define INSIDE right_inside
#define INTERSECT right_intersect

    CLIP2;

    int tmp;
    for(i=0; i<ndest; i++) {
	tmp = (int) (16.0 * src[i].x);
	src[i].x = ((FLOAT)tmp)/16.0;
	tmp = (int) (16.0 * src[i].y);
	src[i].y = ((FLOAT)tmp)/16.0;
    }

    for(i=2; i<ndest; i++)
	grDrawTriangle(&src[0],&src[i-1],&src[i]);
}
