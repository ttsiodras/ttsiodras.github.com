WHAT IS THIS?
=============

This package contains the Win32 binary of a simple polygon-based
3D renderer:

    http://users.softlab.ece.ntua.gr/~ttsiod/renderer.html

Compilation was done through TDM/MinGW, utilizing OpenMP for automatic
usage of multi-core and multi-CPU architectures.

Copying verbatim from the README in the source code package:

"Put simply: The programs supplied allow interactive visualization 
of 3D triangle meshes". This they do in increasing levels of detail,
with the top-most being (a) complete Phong shading per-pixel with
shadow-mapping and (b) raytracer with reflections, shadows and anti-aliasing.

The renderer reads the triangle mesh information from:
- .3ds files, the well known 3D Studio format
- .tri files, a simple binary dump of vertex and triangle data.
- .ply files (partial support), for files saved from shadevis

RUNNING
=======

Run "runme.bat", or equivalently

	renderer.exe chessboard.tri

or try the other two available 3D objects (for more objects, 
get the source package from the site):

	renderer.exe legocar.3ds
	renderer.exe trainColor.tri

- Hit 'H' for help.
- Hit 'R' to stop/start auto-spin.
- Fly around with the cursor keys,A,Z and rotate the light with Q,W. 
- Keys '1' to '0' (as well as PgUp/PgDown) change the rendering mode: 
    Points -> Points with culling -> Interpolated ambient Occlusion -> 
    Gouraud -> Phong -> Shadowmaps -> -> Soft shadowmaps -> 
    Raytracing -> Antialiased raytracing.
- S and F are 'strafe' left/right, E and D are 'strafe' up/down.
- ESC quits. 

USAGE
=====

Usage: renderer [OPTIONS] [FILENAME]

  -h         this help
  -r         print FPS reports to titlebar (every 5 seconds)
  -c <file>  print benchmark results to 'file'
  -b         benchmark rendering of N frames (default: 100)
  -n N       set number of benchmarking frames
  -w         use two lights
  -m <mode>  rendering mode:
       1 : point mode
       2 : points based on triangles (culling,color)
       3 : triangles, wireframe anti-aliased
       4 : triangles, ambient colors
       5 : triangles, Gouraud shading, ZBuffer
       6 : triangles, per-pixel Phong, ZBuffer
       7 : triangles, per-pixel Phong, ZBuffer, Shadowmaps
       8 : triangles, per-pixel Phong, ZBuffer, Soft shadowmaps
       9 : raytracing, with shadows and reflections
       0 : raytracing, with shadows, reflections and anti-aliasing


Enjoy!

Thanassis Tsiodras, Dr.-Ing.
ttsiodras_at-no-spam_thanks-gmail_dot-com
