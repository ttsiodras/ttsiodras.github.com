/*
 *  trender - 3D Studio .ASC files realtime renderer
 *  Copyright (C) 1999  Thanassis Tsiodras (ttsiod@softlab.ntua.gr)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#include "glide.h"

#include "defines.h"
#include "types.h"
#include "vgalib.h"

extern void SuthHodgTriangleWithClip(GrVertex *a, GrVertex *b, GrVertex *c);

//#define NO_CLIPPER

void ZBufferTri(POLY *data) 
{
    POINT *p1,*p2,*p3, *tmp;

    p1=data->P1; p2=data->P2; p3=data->P3;

    FLOAT x,y,z;

    x=p1->X; y=p1->Y; z=p1->Z;
    p1->X = ((MAXX/2) + FOV*y/z);
    p1->Y = ((MAXY/2) - FOV*x/z);

    x=p2->X; y=p2->Y; z=p2->Z;
    p2->X = ((MAXX/2) + FOV*y/z);
    p2->Y = ((MAXY/2) - FOV*x/z);

    x=p3->X; y=p3->Y; z=p3->Z;
    p3->X = ((MAXX/2) + FOV*y/z);
    p3->Y = ((MAXY/2) - FOV*x/z);

    FLOAT miny = p1->Y;
    if (miny>p2->Y) miny=p2->Y;
    if (miny>p3->Y) miny=p3->Y;

    FLOAT maxy = p1->Y;
    if (maxy<p2->Y) maxy=p2->Y;
    if (maxy<p3->Y) maxy=p3->Y;

    // Trivial vertical clipping
    if (miny > (FLOAT)MAXY-1 || maxy < (FLOAT)0)
        return;

    // Trivial horizontal clipping
    if (((p1->X<0)&&(p2->X<0)&&(p3->X<0)) ||
        ((p1->X>(FLOAT)MAXX-1)&&(p2->X>(FLOAT)MAXX-1)&&(p3->X>(FLOAT)MAXX-1)))
        return;

    // Medium-trivial horizontal clipping :)
    if ((p1->X > 32767) || (p1->X < -32768) ||
        (p2->X > 32767) || (p2->X < -32768) ||
        (p3->X > 32767) || (p3->X < -32768))
        return;

    FLOAT minx = p1->X;
    if (minx>p2->X) minx=p2->X;
    if (minx>p3->X) minx=p3->X;

    FLOAT maxx = p1->X;
    if (maxx<p2->X) maxx=p2->X;
    if (maxx<p3->X) maxx=p3->X;

    // Check for requirement of clipping...
    if (minx>=0 && maxx<=MAXX && miny>=0 && maxy<MAXY)
    {
	GrVertex vtxA, vtxB, vtxC;

	vtxA.x = (LONG) p1->X;
	vtxA.y = (LONG) p1->Y;
	vtxA.z = 1.0f / p1->Z;
	vtxA.oow = 1.0f / p1->Z;
	vtxA.r = p1->R;
	vtxA.g = p1->G;
	vtxA.b = p1->B;
	vtxA.a = (LONG) (p1->Z/FADE_SPEED);
	if (vtxA.a>255) vtxA.a = 255;
	if (vtxA.a<0) vtxA.a = 0;

	vtxB.x = (LONG) p2->X;
	vtxB.y = (LONG) p2->Y;
	vtxB.z = 1.0f / p2->Z;
	vtxB.oow = 1.0f / p2->Z;
	vtxB.r = p2->R;
	vtxB.g = p2->G;
	vtxB.b = p2->B;
	vtxB.a = (LONG) (p2->Z/FADE_SPEED);
	if (vtxB.a>255) vtxB.a = 255;
	if (vtxB.a<0) vtxB.a = 0;

	vtxC.x = (LONG) p3->X;
	vtxC.y = (LONG) p3->Y;
	vtxC.z = 1.0f / p3->Z;
	vtxC.oow = 1.0f / p3->Z;
	vtxC.r = p3->R;
	vtxC.g = p3->G;
	vtxC.b = p3->B;
	vtxC.a = (LONG) (p3->Z/FADE_SPEED);
	if (vtxC.a>255) vtxC.a = 255;
	if (vtxC.a<0) vtxC.a = 0;

	/*----------------------------------------------------------- 
	Depth values should be scaled from reciprocated Depth Value 
	then scaled from 0 to 65535.0.

	ooz = ( 1.0f / Z ) * 65535.0f = 65535.0f / Z
	-----------------------------------------------------------*/

	grDrawTriangle( &vtxA, &vtxB, &vtxC );
	return;
    }

    // Clipping required...

#ifdef  NO_CLIPPER
    // No decent clipper available in Linux Glide 2.46...
    // Drop all triangles which need clipping (bleah)
    if (miny<0 || maxy>(MAXY-1))
	return;
    FLOAT minx = p1->X;
    if (minx > p2->X) minx = p2->X;
    if (minx > p3->X) minx = p3->X;

    FLOAT maxx = p1->X;
    if (maxx < p2->X) maxx = p2->X;
    if (maxx < p3->X) maxx = p3->X;
    if (minx<0 || maxx>(MAXX-1))
	return;
#endif

    GrVertex vtxA, vtxB, vtxC;

    vtxA.x = (LONG) p1->X;
    vtxA.y = (LONG) p1->Y;
    vtxA.z = 1.0f / p1->Z;
    vtxA.oow = 1.0f / p1->Z;
    vtxA.r = p1->R;
    vtxA.g = p1->G;
    vtxA.b = p1->B;
    vtxA.a = (LONG) (p1->Z/FADE_SPEED);
    if (vtxA.a>255) vtxA.a = 255;
    if (vtxA.a<0) vtxA.a = 0;
    
    vtxB.x = (LONG) p2->X;
    vtxB.y = (LONG) p2->Y;
    vtxB.z = 1.0f / p2->Z;
    vtxB.oow = 1.0f / p2->Z;
    vtxB.r = p2->R;
    vtxB.g = p2->G;
    vtxB.b = p2->B;
    vtxB.a = (LONG) (p2->Z/FADE_SPEED);
    if (vtxB.a>255) vtxB.a = 255;
    if (vtxB.a<0) vtxB.a = 0;
        
    vtxC.x = (LONG) p3->X;
    vtxC.y = (LONG) p3->Y;
    vtxC.z = 1.0f / p3->Z;
    vtxC.oow = 1.0f / p3->Z;
    vtxC.r = p3->R;
    vtxC.g = p3->G;
    vtxC.b = p3->B;
    vtxC.a = (LONG) (p3->Z/FADE_SPEED);
    if (vtxC.a>255) vtxC.a = 255;
    if (vtxC.a<0) vtxC.a = 0;

    /*----------------------------------------------------------- 
      Depth values should be scaled from reciprocated Depth Value 
      then scaled from 0 to 65535.0.
      
      ooz = ( 1.0f / Z ) * 65535.0f = 65535.0f / Z
      -----------------------------------------------------------*/

#ifdef NO_CLIPPER
    grDrawTriangle( &vtxA, &vtxB, &vtxC );
#else
    SuthHodgTriangleWithClip( &vtxA, &vtxB, &vtxC );
#endif
}
