/*  
 *  HeapCheck - a heap debugging library
 *  Copyright (C) 2001  Thanassis Tsiodras (ttsiod@softlab.ntua.gr)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

// It is intentional here that we are changing the effects of new and delete
// so silence PCLints's warnings about it.
// Gimpel's PCLint will flag error 1771's due to the replacement of new and delete

//lint -e1771

// stdio.h doesn't actually seem to be used, so at a future stage, quieten Lint's warnings
// about it!

#ifdef __cplusplus

// We only exist in debug builds...
#ifdef _DEBUG

#include <windows.h>

#include "HeapCheckPrototypes.h"

// Checks for buffer underuns...
#ifdef PRE_CHECK

void *operator new (size_t size)
{
  return HeapCheckPreFenceMalloc(size);
}

void *operator new[] (size_t size)
{
  return HeapCheckPreFenceMalloc(size);
}

void operator delete (void *p)
{
  if (p != NULL)
  {
    HeapCheckPreFenceFree(p);
  }
}

void operator delete[] (void *p)
{
  if (p != NULL)
  {
    HeapCheckPreFenceFree(p);
  }
}

#else 

// Checks for buffer overuns...
void *operator new (size_t size)
{
  return HeapCheckPostFenceMalloc(size);
}

void *operator new[] (size_t size)
{
  return HeapCheckPostFenceMalloc(size);
}

void operator delete (void *p)
{
  if (p != NULL)
  {
    HeapCheckPostFenceFree(p);
  }
}

void operator delete[] (void *p)
{
  if (p != NULL)
  {
    HeapCheckPostFenceFree(p);
  }
}

#endif /* PRE_CHECK */

#endif /* _DEBUG */

#endif /* __cplusplus */

//lint +e1771
