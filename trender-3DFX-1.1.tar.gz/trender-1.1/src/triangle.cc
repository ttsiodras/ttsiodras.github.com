/*
 *  trender - 3D Studio .ASC files realtime renderer
 *  Copyright (C) 1999  Thanassis Tsiodras (ttsiod@softlab.ntua.gr)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "3dtypes.h"

Triangle::init(Vertex *a, Vertex *b, Vertex *c, Material *m)
{
    v0 = a; v1 = b; v2 = c;

    fCenterX = ((v0->GetX()) + (v1->GetX()) + (v2->GetX()))/3;
    fCenterY = ((v0->GetY()) + (v1->GetY()) + (v2->GetY()))/3;
    fCenterZ = ((v0->GetZ()) + (v1->GetZ()) + (v2->GetZ()))/3;

    material = m;

    visible = FALSE;
}
