/*
 *  trender - 3D Studio .ASC files realtime renderer
 *  Copyright (C) 1999  Thanassis Tsiodras (ttsiod@softlab.ntua.gr)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <signal.h>
#include <unistd.h>

#include "3dtypes.h"

#include "glide.h"

#include "camera.h"
#include "defines.h"
#include "misc.h"

#ifdef KEYBOARD_CONTROLLED
#include <vgakeyboard.h>
#endif

static void (*oldhandler)(int) = NULL;
static FILE *fp = NULL;
static int debug = 0;

void usage(char *exename);
void info(void);

void handler(int signo)
{
	if (signo != SIGHUP) {
		printf("oops..."); 
		return; 
	}
        signal(SIGHUP, oldhandler);
#ifdef KEYBOARD_CONTROLLED
        keyboard_close();
#endif
        if (debug)
	    fclose(fp);
	grGlideShutdown();
        printf("exiting through SIGHUP...");
        exit(0);
}

void info()
{
    inform("%s 3DFX v%s     Written by Thanassis Tsiodras "
	    "(ttsiod@softlab.ntua.gr)\n\n", PACKAGE, VERSION);
    inform("A simple polygon based renderer, supporting:\n");
    inform("- Point rendering\n");
    inform("- Wireframe rendering\n");
    inform("- Gouraud shaded, Z buffer rendering, with ambient,diffuse ");
    inform("and specular lighting\n");
    inform("\n\nRenderer compiled on %s %s\n", __DATE__, __TIME__);
}

void usage(char *exename)
{
    inform("Usage: %s [options] filename.asc\n", exename);
    inform("where options are:\n");
    inform("\t-mode 0      : plot points\n");
    inform("\t-mode 1      : draw wireframe model\n");
    inform("\t-mode 3      : draw gouraud shaded model\n");
    inform("\t-dth angle   : degrees to rotate per step\n");
    inform("\t-dphi angle  : degrees to rotate per step\n");
    inform("\t-dmove step  : percent of object radius to move per step\n");
    inform("\t-novsync     : disable vertical synchronization\n");
    inform("\t-debug       : dump info in log.txt per step\n");
    inform("\t-about       : Information about the program\n\n");
    inform("For example:\n%s ../3d-objects/torus.asc\n\n",
	exename);
    inform("To navigate, use the cursor keys, A, Z, W, and hit ESCAPE to exit.\n\n");
}

void main(int argc, char *argv[])
{
    Object3D *obj = NULL;
    int mode=3, oo=1;
    FLOAT dphi=0.5,dth=0.5, step=25;
    char *fname = NULL;
    GrHwConfiguration hwconfig;
    int vsync = 1;

    if (getuid())
	panic("Only root can run 3DFX programs. Sorry...\n");

    while(oo<argc) {
	if (*argv[oo]=='-') {
	    if(!strcmp(argv[oo], "-debug")) {
		debug = 1;
		oo++;
		continue;
	    } else if(!strcmp(argv[oo], "-novsync")) {
		vsync = 0;
		oo++;
		continue;
	    } else if(!strcmp(argv[oo], "-about")) {
		info();
		exit(0);
	    } else if(!strcmp(argv[oo], "-mode")) {
		oo++;
		if (oo>=argc) {
		    usage(argv[0]);
		    panic("0,1 or 3 must follow -mode\n");
		}
		int res = sscanf(argv[oo], "%d", &mode);
		oo++;
		if ((mode!=0 && mode!=1 && mode!=3)||(res!=1)) {
		    usage(argv[0]);
		    panic("0,1 or 3 must follow -mode\n");
		}
		continue;
	    } else if(!strcmp(argv[oo], "-dth")) {
		oo++;
		if (oo>=argc) {
		    usage(argv[0]);
		    panic("angle must follow -dth\n");
		}
		dth = atof(argv[oo]);
		oo++;
		if (dth<=0 || dth>=360) {
		    usage(argv[0]);
		    panic("angle must be a number between 1 and 359 degrees\n");
		}
		continue;	
	    } else if(!strcmp(argv[oo], "-dphi")) {
		oo++;
		if (oo>=argc) {
		    usage(argv[0]);
		    panic("angle must follow -dphi\n");
		}
		dphi = atof(argv[oo]);
		oo++;
		if (dphi<=0 || dphi>=360) {
		    usage(argv[0]);
		    panic("angle must be a number between 1 and 359 degrees\n");
		}
		continue;	
	    } else if(!strcmp(argv[oo], "-dmove")) {
		oo++;
		if (oo>=argc) {
		    usage(argv[0]);
		    panic("step must follow -dmove\n");
		}
		step = atof(argv[oo]);
		oo++;
		if (step<=0 || step>=100) {
		    usage(argv[0]);
		    panic("step must be between 1 and 100 (percentage)\n");
		}
		continue;	
	    } else {
		usage(argv[0]);
		panic("Unrecognized %s\n", argv[oo]);
	    }
	} else {
	    if (!fname)
		fname = argv[oo++];
	    else {
		usage(argv[0]);
	    	panic("what to load? %s or %s\n", fname, argv[oo]);
	    }
	}
    }
    if (!fname) {
    	usage(argv[0]);
	panic("No filename given\n");
    }
    inform("\nLoading %s...\n\n", fname);
    obj = new Object3D(fname);

    if (debug) {
	fp = fopen("log.txt", "w");
	fprintf(fp, "Rendering sequence starts...\n");
	fflush(fp);
    }
#ifdef KEYBOARD_CONTROLLED
    inform("Attempting to use direct keyboard control through SVGALib...\n");
    inform(	"If this crashes, you probably aren't root,"
	   	"or you are running under X. Get out!\n");
    keyboard_init();

    /* debugging killer (restores kb, text mode) */
    oldhandler = signal(SIGHUP, handler);
#endif

    /* Initialize Glide */
    grGlideInit();
    if(!grSstQueryHardware( &hwconfig ) )
	panic("Could not open 3DFX hardware");

    grSstSelect( 0 );
    if (!grSstWinOpen( 0,
            GR_RESOLUTION_640x480,
            GR_REFRESH_75Hz,
            GR_COLORFORMAT_ABGR,
            GR_ORIGIN_UPPER_LEFT,
            2, 1 ) )
	panic("Glide Hardware not responding to SstWinOpen...\n");

    /* Set up Render State - flat shading + Z-buffering */

    switch(mode) {
    case 0:
    case 1:
        grColorCombine( GR_COMBINE_FUNCTION_LOCAL,
			GR_COMBINE_FACTOR_NONE,
			GR_COMBINE_LOCAL_CONSTANT,
			GR_COMBINE_OTHER_NONE,
			FXFALSE );
	grConstantColorValue(~0);
	break;
/*
    case 1:
        grColorCombine( GR_COMBINE_FUNCTION_LOCAL,
			GR_COMBINE_FACTOR_NONE,
			GR_COMBINE_LOCAL_CONSTANT,
			GR_COMBINE_OTHER_NONE,
			FXFALSE );
	grDepthBufferMode( GR_DEPTHBUFFER_WBUFFER );
	grDepthBufferFunction( GR_CMP_LESS );
	grDepthMask( FXTRUE );

	grFogColorValue(BACKGROUND);
	grFogMode(GR_FOG_WITH_ITERATED_ALPHA);
	break;
*/
    case 2:
    case 3:
        grColorCombine( GR_COMBINE_FUNCTION_LOCAL,
			GR_COMBINE_FACTOR_NONE,
			GR_COMBINE_LOCAL_ITERATED,
			GR_COMBINE_OTHER_NONE,
			FXFALSE );
//	grCullMode(GR_CULL_POSITIVE);
	grDepthBufferMode( GR_DEPTHBUFFER_WBUFFER );
	grDepthBufferFunction( GR_CMP_LESS );
	grDepthMask( FXTRUE );

	grFogColorValue(BACKGROUND);
	grFogMode(GR_FOG_WITH_ITERATED_ALPHA);

	break;
    default:
	panic("Mode must be 0-3\n");
    }

    grClipWindow(0, 0, (FxU32) 640.0, (FxU32) 480.0);
    
    LONG frames=0;

    FLOAT th,phi,ddd;
    FLOAT vx,vy,vz; // eye point
    FLOAT px,py,pz; // lookat point

    th=180.0; phi=90.0;

    ddd=obj->GetRadiusZ()*step/100;
    if (obj->GetRadiusX()*step/100>ddd)
	ddd=obj->GetRadiusX()*step/100;
    if (obj->GetRadiusY()*step/100>ddd)
	ddd=obj->GetRadiusY()*step/100;

    vx = 2*obj->GetRadiusX(); vy = vz = 0;
    px = py = pz = 0;

    Camera sony(vx, vy, vz, px, py, pz);

    FLOAT torchTheta = 50;
    Light torch(100,100,100, 255, 100,100,100);
    torch.SetPosition(  8*obj->GetRadiusX()*sin((torchTheta)*3.14159*2/360),
			8*obj->GetRadiusY()*cos((torchTheta)*3.14159*2/360),
			8*obj->GetRadiusZ());

    LONG st=readtime();

#ifndef KEYBOARD_CONTROLLED
    while (frames<(90/dth)) {
#else
    while(!keyboard_keypressed(SCANCODE_ESCAPE)) {
	px=vx+ddd*2*sin(M_2PI*phi/360)*cos(M_2PI*th/360);
	py=vy+ddd*2*sin(M_2PI*phi/360)*sin(M_2PI*th/360);
	pz=vz+ddd*2*cos(M_2PI*phi/360);
#endif
	sony.Set(vx,vy,vz, px,py,pz);

        grBufferClear( BACKGROUND, 0, GR_WDEPTHVALUE_FARTHEST );
	if (debug) {
		fprintf(fp, "x=%18.13f y=%18.13f z=%18.13f ...", 
				vx, vy, vz, th, phi);
		fflush(fp);
	}

        switch(mode) {
        case 0:
            obj->RenderDots(&sony);
            break;
        case 1:
            obj->RenderWireFrame(&sony);
            break;
        case 3:
            if (obj->RenderZGouraud(&sony, &torch) == -1)
	    	frames=200;
            break;
        }

	if (debug) { fprintf(fp, "done"); fflush(fp); }
        grBufferSwap(vsync);
	if (debug) { fprintf(fp, ".\n"); fflush(fp); }
    
        frames++;

#ifndef KEYBOARD_CONTROLLED
	vx = 2*obj->GetRadiusX()*cos(frames*dth*M_2PI/360); 
	vy = 2*obj->GetRadiusY()*sin(frames*dth*M_2PI/360); 
	vz = 2*obj->GetRadiusZ(); 
#else
	keyboard_update();

	if (keyboard_keypressed(SCANCODE_Z)) {
	    vz=vz-ddd/5*cos(M_2PI*phi/360);
	    vx=vx-ddd/5*sin(M_2PI*phi/360)*cos(M_2PI*th/360);
	    vy=vy-ddd/5*sin(M_2PI*phi/360)*sin(M_2PI*th/360);
	}
	if (keyboard_keypressed(SCANCODE_A)) {
	    vz=vz+ddd/5*cos(M_2PI*phi/360);
	    vx=vx+ddd/5*sin(M_2PI*phi/360)*cos(M_2PI*th/360);
	    vy=vy+ddd/5*sin(M_2PI*phi/360)*sin(M_2PI*th/360);
	}
	if (keyboard_keypressed(SCANCODE_CURSORBLOCKDOWN)) phi=phi+dphi;
	if (keyboard_keypressed(SCANCODE_CURSORBLOCKUP)) phi=phi-dphi;
	if (keyboard_keypressed(SCANCODE_CURSORBLOCKLEFT)) th=th+dth;
	if (keyboard_keypressed(SCANCODE_CURSORBLOCKRIGHT)) th=th-dth;

	if (phi>179.0) phi=179.0;
	if (phi<00) phi=1.0;
	if (keyboard_keypressed(SCANCODE_W)) {
	    torchTheta += dth;
	    torch.SetPosition(
		8*obj->GetRadiusX()*sin((torchTheta)*3.14159*2/360),
		8*obj->GetRadiusY()*cos((torchTheta)*3.14159*2/360),
		8*obj->GetRadiusZ());
	}
#endif
    }

    LONG en=readtime();
#ifdef KEYBOARD_CONTROLLED
    keyboard_close();
    signal(SIGHUP, oldhandler);
#endif
    if (debug)
	fclose(fp);
    grGlideShutdown();

    inform("\n\nScene had %d triangles and ", obj->GetNoOfTriangles());
    inform("%d vertexes.\n", obj->GetNoOfVertexes());
    inform("Rendering speed: ");
    inform("%d", (int)(((float)frames*(obj->GetNoOfTriangles()))/((FLOAT)(en-st)/1000.0)));
    inform(" triangles/sec (");
    inform("%lf frames/sec).\n", ((FLOAT) frames)/((FLOAT)(en-st)/1000.0));

    if (obj)
        delete obj;
}
