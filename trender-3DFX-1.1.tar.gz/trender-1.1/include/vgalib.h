/*
 *  trender - 3D Studio .ASC files realtime renderer
 *  Copyright (C) 1999  Thanassis Tsiodras (ttsiod@softlab.ntua.gr)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef __VGALIB_INCLUDED__
#define __VGALIB_INCLUDED__

//#define DEBUG
#include <glide.h>
#include "types.h"
#include "3dtypes.h"

void init256(void);
void close256(void);
void set256Palette(unsigned char *s);
inline void plot(int r,int k)
{
    GrVertex a;

    a.x = r; a.y = k;
    grDrawPoint(&a);
}
void vgaline(int x1,int y1,int x2,int y2,unsigned char colour,char *page);
void pal(void);
void mvgaline(FLOAT x1,FLOAT y1,FLOAT x2,FLOAT y2,unsigned char colour);
void mvgalineMaterial(FLOAT x1,FLOAT y1,FLOAT x2,FLOAT y2,Material *);
void mvgalineDepth(FLOAT x1,FLOAT y1,FLOAT z1,FLOAT x2,FLOAT y2,FLOAT z2,Material *);
void code(FLOAT x,FLOAT y,unsigned char *c);
void clear_page(void);
void show_page(void);
void ZBufferTri(POLY *data);

#endif
