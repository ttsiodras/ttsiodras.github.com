/*
 *  trender - 3D Studio .ASC files realtime renderer
 *  Copyright (C) 1999  Thanassis Tsiodras (ttsiod@softlab.ntua.gr)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
#include <string.h>
#include "types.h"
#include "3dtypes.h"
#include "vgalib.h"
#include "glide.h"
#include "camera.h"
#include "defines.h"

/////////////////////////////////////////////////////////////
// Macros and utility functions for parsing the .ASC file  //
/////////////////////////////////////////////////////////////

// Search for keyword in file pointed by FP
#define   fsearch(FP,str)     do {					\
				fscanf(FP,"%s",tmpSTR);			\
				if(feof(FP)) return;                    \
		              } while(strncmp(tmpSTR,str,strlen(str))!=0);

// Search for char in file pointed by FP
#define   fsearchar(FP,chr)    while(fgetc(FP) != chr);

// Get Quoted string from file pointed by F
#define	getqstring(FP,str) {        \
    fsearchar(FP,'"');	            \
    fscanf(FP,"%[^\"]",str);   	    \
} /* skip 1st " read till 2nd " */

int ftrisearch(FILE *FP,char *str)
{
    char tmpSTR[80];
    do {
	fscanf(FP,"%s",tmpSTR);	
	if(feof(FP)) return(-2);
    } while(strncmp(tmpSTR,str,strlen(str))!=0);
    return(0);
}

void Object3D::load_object(char *szFname, FLOAT fScale)
{
    FILE *in;
    LONG nv = 0, np = 0;
    char tmpSTR[80], material[80];
    LONG vertexNR,polyNR,pointA,pointB,pointC;
    FLOAT fVertexX, fVertexY, fVertexZ;
    char *fname = new char[strlen(szFname)+10];

    inform("Preparing Object Loading...\n");
    strcpy(fname,szFname);
    if (!strrchr(fname,'.')) {
        strcat(fname,".asc");	// Append .asc extension if necessary
    }

    // First, figure out the total vertexes and triangles of the ASC file.
    lTotalVertexes = lTotalTriangles = 0;
    in = fopen(fname, "r");
    if (!in)
	panic("Can't find '%s'\n", fname);
    while(ftrisearch(in,"Tri-mesh")==0)
    {
	fsearch(in,"Vertices:");             //get VertexNUM
	fscanf(in,"%d",&nv);
	fsearch(in,"Faces:");                //get PolyNUM
	fscanf(in,"%d",&np);
	lTotalVertexes += nv;
	lTotalTriangles += np;
    }
    fclose(in);

    // Allocate enough memory for all vertexes and all triangles
    headVertex = new Vertex[lTotalVertexes];
    headTriangle = new Triangle[lTotalTriangles];
    if (!headVertex || !headTriangle)
	panic("Not enough memory to load object\n");
    // And clear it
    memset(headVertex, 0, sizeof(Vertex)*lTotalVertexes);
    memset(headTriangle, 0, sizeof(Triangle)*lTotalTriangles);
    inform("Attempting to load %d vertexes and %d triangles...\n", 
	lTotalVertexes, lTotalTriangles);

    // Now start calculating the scaling factor for the object...
    while(1) {
        in = fopen(fname, "r");
        if (!in)
            panic("Can't open '%s' in Object construction\n", fname);

        radiusX=0;
        radiusY=0;
        radiusZ=0;

        lTotalTriangles=0;
        lTotalVertexes=0;

        while(ftrisearch(in,"Tri-mesh")==0)
        {
                                                 // Search for triangle mesh
            fsearch(in,"Vertices:");             // Get vertex number
            fscanf(in,"%d",&nv);
            fsearch(in,"Faces:");                // Get polygon number
            fscanf(in,"%d",&np);

            fsearch(in,"Vertex"); fsearch(in,"list:");

            LONG i;
            for (i=0; i<nv; i++) {
                fsearch(in,"Vertex");
                fscanf(in,"%d",&vertexNR);
                fsearchar(in,':');
                fsearchar(in,':');
                fscanf(in,"%f",&fVertexX);
                fsearchar(in,':');
                fscanf(in,"%f",&fVertexY);
                fsearchar(in,':');
                fscanf(in,"%f",&fVertexZ);

                fVertexX *= fScale;
                fVertexY *= fScale;
                fVertexZ *= fScale;
		if (fabs(fVertexX) > radiusX) radiusX = (fabs(fVertexX));
		if (fabs(fVertexY) > radiusY) radiusY = (fabs(fVertexY));
		if (fabs(fVertexZ) > radiusZ) radiusZ = (fabs(fVertexZ));
            }
            lTotalVertexes+=nv;
            lTotalTriangles+=np;
        }
        fclose(in);

        FLOAT max_radius = radiusX;
        if (radiusY>max_radius) max_radius = radiusY;
        if (radiusZ>max_radius) max_radius = radiusZ;

        if ((max_radius>250.0) || (max_radius<225.0)) {
            fScale = fScale*250.0/max_radius;
            inform("Recalculating object in new scale...\n");
        }
        else {
            fScale = fScale*250.0/max_radius;
            inform("Final pass ...\n");
	    break;
        }
    }

    // Now start loading the actual data...

    in = fopen(fname, "r");
    if (!in)
	panic("Can't open '%s' in Object construction\n", fname);

    radiusX=0;
    radiusY=0;
    radiusZ=0;

    lTotalTriangles=0;
    lTotalVertexes=0;

    while(ftrisearch(in,"Tri-mesh")==0)
    {
					     // Search for triangle mesh
	fsearch(in,"Vertices:");             // Get vertex number
	fscanf(in,"%d",&nv);
	fsearch(in,"Faces:");                // Get polygon number
	fscanf(in,"%d",&np);

	fsearch(in,"Vertex"); fsearch(in,"list:");

	LONG i;
	for (i=0; i<nv; i++) {
	    fsearch(in,"Vertex");
	    fscanf(in,"%d",&vertexNR);
	    fsearchar(in,':');
	    fsearchar(in,':');
	    fscanf(in,"%f",&fVertexX);
	    fsearchar(in,':');
	    fscanf(in,"%f",&fVertexY);
	    fsearchar(in,':');
	    fscanf(in,"%f",&fVertexZ);

	    fVertexX *= fScale;
	    fVertexY *= fScale;
	    fVertexZ *= fScale;
	    if (fabs(fVertexX) > radiusX) radiusX = (fabs(fVertexX));
	    if (fabs(fVertexY) > radiusY) radiusY = (fabs(fVertexY));
	    if (fabs(fVertexZ) > radiusZ) radiusZ = (fabs(fVertexZ));

	    headVertex[lTotalVertexes+i].init(fVertexX, fVertexY, fVertexZ); 
	}
	fsearch(in,"Face"); fsearch(in,"list:");
	for (i=0; i<np; i++) {
	    Material *node;

	    fsearch(in,"Face");
	    fscanf(in,"%d",&polyNR);
	    if (polyNR != i) {		// Sanity checking...
		inform("Error:\ni=%d, polyNR=\n", i, polyNR);
		inform("pointA=%d,pointB=%d,pointC=%d\n", 
		    pointA, pointB, pointC);
		inform("material=%s,tmpSTR=%s\n", material, tmpSTR);
		panic("Error in Reading Faces\n");
	    }
	    fsearchar(in,':');
	    fsearchar(in,':');
	    fscanf(in,"%d",&pointA);
	    fsearchar(in,':');
	    fscanf(in,"%d",&pointB);
	    fsearchar(in,':');
	    fscanf(in,"%d",&pointC);

//                fscanf(in,"%[^\n]%*9s",tmpSTR);
	    fsearchar(in,':');
	    fsearchar(in,'"');
//                getqstring(in, material);
	    fscanf(in,"%[^\"]", tmpSTR);
	    sprintf(material, "\"%s\"", tmpSTR);
	    {
		BOOLEAN found=FALSE;

		if ((material[0]=='"') &&
		    (tolower(material[1])=='r') &&
		    (isdigit(material[2])))
		{
		    node=GetHeadMaterial();

		    while(node!=NULL) {

			if(strcmp(material, node->GetMaterialName()) == 0) {
			    found = TRUE;
			    break;
			}
			else
			    node = node->GetNextNode();
		    }
		    if(!found) {
			node = new Material(this, material);
		    }
		}
		else
		    node = white;

	    }

	    headTriangle[lTotalTriangles+i].init( 
		    &headVertex[lTotalVertexes + pointA],
		    &headVertex[lTotalVertexes + pointB],
		    &headVertex[lTotalVertexes + pointC],
		    node);

        }
	lTotalVertexes+=nv;
	lTotalTriangles+=np;
    }
    fclose(in);
    delete [] fname;
}


void Object3D::fix_normals(void)
{
    FLOAT aax, aay, aaz, bbx, bby, bbz;
    FLOAT dumx, dumy, dumz;
    FLOAT fSumm;
    LONG i;
    Triangle *tri;

    LONG lTrianglesWithNoNormal = 0;
    tri=headTriangle; 
    for(i=0; i<lTotalTriangles; i++) {
        Vertex *A = tri->GetV0();
        Vertex *B = tri->GetV1();
        Vertex *C = tri->GetV2();

        aax = B->GetX() - A->GetX();
        aay = B->GetY() - A->GetY();
        aaz = B->GetZ() - A->GetZ();

        bbx = C->GetX() - A->GetX();
        bby = C->GetY() - A->GetY();
        bbz = C->GetZ() - A->GetZ();

        dumx=aay*bbz-bby*aaz;
        dumy=bbx*aaz-aax*bbz;
        dumz=aax*bby-aay*bbx;

	fSumm=sqrt(dumx*dumx+dumy*dumy+dumz*dumz);
        if (fSumm>1e-5) {
	    
	    dumx = dumx/fSumm;
	    dumy = dumy/fSumm;
	    dumz = dumz/fSumm;

	}
	else {
	    lTrianglesWithNoNormal++;
	}

        tri->SetNormals(dumx, dumy, dumz);

        A->AddToNormal(dumx, dumy, dumz);
        B->AddToNormal(dumx, dumy, dumz);
        C->AddToNormal(dumx, dumy, dumz);

        tri++;
    }

    if (lTrianglesWithNoNormal) 
	inform("%d triangles could not produce a normal...\n",
	    lTrianglesWithNoNormal);
    Vertex *v;
    LONG lCountz=0;

    v=headVertex;
    for(i=0; i<lTotalVertexes; i++) {
        fSumm=sqrt(( (v->GetNormalX()) * (v->GetNormalX()) +
                     (v->GetNormalY()) * (v->GetNormalY()) +
                     (v->GetNormalZ()) * (v->GetNormalZ()) ));
        if (fSumm<1e-5) {
            lCountz++;
            fSumm=1.0;
            v->SetAlways();
        }
        v->SetNormals(
            ((FLOAT) v->GetNormalX())/fSumm,
            ((FLOAT) v->GetNormalY())/fSumm,
            ((FLOAT) v->GetNormalZ())/fSumm
        );
        v++;
    }
    if(lCountz) {
        inform("I found %d non-colorable polygons.\n", lCountz);
    }
}


void Object3D::RenderDots(Camera *camera)
{
    Vertex *node;
    int i = 0;
 
    node=headVertex; 
    for(i=0; i<lTotalVertexes; i++) {
        node->Transform(camera);
	if (node->GetTransformedZ()>0)
	    plot(
		MAXX/2+
		(int)(FOV*node->GetTransformedY()/node->GetTransformedZ()),
		MAXY/2-
		(int)(FOV*node->GetTransformedX()/node->GetTransformedZ()));
        node++;
    }
}


void Object3D::RenderWireFrame(Camera *camera)
{
    Vertex *node;
    Triangle *tri;
    LONG i;
    
    node=headVertex; 
    for(i=0; i<lTotalVertexes; i++, node++)
        node->Transform(camera);

    tri=headTriangle; 
    for(i=0; i<lTotalTriangles; i++, tri++) {

        FLOAT eex, eey, eez;

	eex = camera->GetEyeX() - tri->GetCenterX();
	eey = camera->GetEyeY() - tri->GetCenterY();
	eez = camera->GetEyeZ() - tri->GetCenterZ();

	if ((tri->GetV0()->GetTransformedZ() <= ZCLIP) ||
	    (tri->GetV1()->GetTransformedZ() <= ZCLIP) ||
	    (tri->GetV2()->GetTransformedZ() <= ZCLIP))
	    continue;

	if
        (

            (
                eex * tri->GetNormalX() +
	        eey * tri->GetNormalY() +
	        eez * tri->GetNormalZ() >=0
            )

/*
            ||
            (
                tri->GetV0()->IsAlways() ||
                tri->GetV1()->IsAlways() ||
                tri->GetV2()->IsAlways()
            )
*/
        )
        {
	    FLOAT x0,y0,z0, x1,y1,z1, x2,y2,z2;

	    x0 = tri->GetV0()->GetTransformedX();
	    y0 = tri->GetV0()->GetTransformedY();
	    z0 = tri->GetV0()->GetTransformedZ();
	    x1 = tri->GetV1()->GetTransformedX();
	    y1 = tri->GetV1()->GetTransformedY();
	    z1 = tri->GetV1()->GetTransformedZ();
	    x2 = tri->GetV2()->GetTransformedX();
	    y2 = tri->GetV2()->GetTransformedY();
	    z2 = tri->GetV2()->GetTransformedZ();

            mvgalineMaterial(
		(MAXX/2) + FOV*y0/z0,
		(MAXY/2) - FOV*x0/z0,
		(MAXX/2) + FOV*y1/z1,
		(MAXY/2) - FOV*x1/z1,
                tri->GetMaterial());
            mvgalineMaterial(
		(MAXX/2) + FOV*y1/z1,
		(MAXY/2) - FOV*x1/z1,
		(MAXX/2) + FOV*y2/z2,
		(MAXY/2) - FOV*x2/z2,
                tri->GetMaterial());
            mvgalineMaterial(
		(MAXX/2) + FOV*y2/z2,
		(MAXY/2) - FOV*x2/z2,
		(MAXX/2) + FOV*y0/z0,
		(MAXY/2) - FOV*x0/z0,
                tri->GetMaterial());
        }
    }
}


LONG Object3D::RenderZGouraud(Camera *camera, Light *light)
{
    Vertex *node;
    Triangle *tri;
    LONG i;

    if (light)
        for(i=0,node=headVertex; i<lTotalVertexes; i++,node++) {
            node->Transform(camera);
            node->Illuminate(light, camera);
        }
    else
        for(i=0,node=headVertex; i<lTotalVertexes; i++,node++) {
            node->Transform(camera);
            node->SetIntensity(128);
        }

    POLY p;
    POINT po1, po2, po3;

    p.P1=&po1; p.P2=&po2; p.P3=&po3;

    for(i=0,tri=headTriangle; i<lTotalTriangles; i++,tri++) {

	LONG BadVertexes;
	FLOAT x0,x1,x2, y0,y1,y2, z0,z1,z2;
	FLOAT r0,g0,b0, r1,g1,b1, r2,g2,b2;

        FLOAT eex, eey, eez;

	eex = camera->GetEyeX() - tri->GetCenterX();
	eey = camera->GetEyeY() - tri->GetCenterY();
	eez = camera->GetEyeZ() - tri->GetCenterZ();

	if (eex * tri->GetNormalX() +
	    eey * tri->GetNormalY() +
	    eez * tri->GetNormalZ() <=0)
	    continue;

        po1.R     = tri->GetMaterial()->GetR()*
                    (tri->GetV0()->GetIntensity())/255.0;
        po1.G     = tri->GetMaterial()->GetG()*
                    (tri->GetV0()->GetIntensity())/255.0;
        po1.B     = tri->GetMaterial()->GetB()*
                    (tri->GetV0()->GetIntensity())/255.0;

        po2.R     = tri->GetMaterial()->GetR()*
                    (tri->GetV1()->GetIntensity())/255.0;
        po2.G     = tri->GetMaterial()->GetG()*
                    (tri->GetV1()->GetIntensity())/255.0;
        po2.B     = tri->GetMaterial()->GetB()*
                    (tri->GetV1()->GetIntensity())/255.0;

        po3.R     = tri->GetMaterial()->GetR()*
                    (tri->GetV2()->GetIntensity())/255.0;
        po3.G     = tri->GetMaterial()->GetG()*
                    (tri->GetV2()->GetIntensity())/255.0;
        po3.B     = tri->GetMaterial()->GetB()*
                    (tri->GetV2()->GetIntensity())/255.0;

	BadVertexes = 0;
        if (tri->GetV0()->GetTransformedZ()<ZCLIP)
	    BadVertexes++;
	if (tri->GetV1()->GetTransformedZ()<ZCLIP)
	    BadVertexes++;
	if (tri->GetV2()->GetTransformedZ()<ZCLIP)
	    BadVertexes++;

	if (BadVertexes == 0) {
	    po1.X = tri->GetV0()->GetTransformedX();
	    po1.Y = tri->GetV0()->GetTransformedY();
	    po1.Z = tri->GetV0()->GetTransformedZ();
    
	    po2.X = tri->GetV1()->GetTransformedX();
	    po2.Y = tri->GetV1()->GetTransformedY();
	    po2.Z = tri->GetV1()->GetTransformedZ();

	    po3.X = tri->GetV2()->GetTransformedX();
	    po3.Y = tri->GetV2()->GetTransformedY();
	    po3.Z = tri->GetV2()->GetTransformedZ();

	    ZBufferTri(&p);

	    continue;
	}

	r0 = po1.R; g0 = po1.G; b0 = po1.B;
	r1 = po2.R; g1 = po2.G; b1 = po2.B;
	r2 = po3.R; g2 = po3.G; b2 = po3.B;

	x0 = tri->GetV0()->GetTransformedX();
	y0 = tri->GetV0()->GetTransformedY();
	z0 = tri->GetV0()->GetTransformedZ();

	x1 = tri->GetV1()->GetTransformedX();
	y1 = tri->GetV1()->GetTransformedY();
	z1 = tri->GetV1()->GetTransformedZ();

	x2 = tri->GetV2()->GetTransformedX();
	y2 = tri->GetV2()->GetTransformedY();
	z2 = tri->GetV2()->GetTransformedZ();

	switch(BadVertexes) {

	case 3:
	    continue;
	case 1:

	    FLOAT r4,g4,b4, r5,g5,b5;

	    if (z0<ZCLIP) {
		FLOAT x4,y4,z4, x5,y5,z5;

		x4 = x0 + (ZCLIP-z0)*(x1-x0)/(z1-z0);
		y4 = y0 + (ZCLIP-z0)*(y1-y0)/(z1-z0);
		z4 = ZCLIP;

		r4 = r0 + (ZCLIP-z0)*(r1-r0)/(z1-z0);
		g4 = g0 + (ZCLIP-z0)*(g1-g0)/(z1-z0);
		b4 = b0 + (ZCLIP-z0)*(b1-b0)/(z1-z0);

		x5 = x0 + (ZCLIP-z0)*(x2-x0)/(z2-z0);
		y5 = y0 + (ZCLIP-z0)*(y2-y0)/(z2-z0);
		z5 = ZCLIP;

		r5 = r0 + (ZCLIP-z0)*(r2-r0)/(z2-z0);
		g5 = g0 + (ZCLIP-z0)*(g2-g0)/(z2-z0);
		b5 = b0 + (ZCLIP-z0)*(b2-b0)/(z2-z0);

		po1.X = x4; po1.Y = y4; po1.Z = z4;
		po2.X = x1; po2.Y = y1; po2.Z = z1;
		po3.X = x5; po3.Y = y5; po3.Z = z5;

		po1.R = r4; po1.G = g4; po1.B = b4;
		po2.R = r1; po2.G = g1; po2.B = b1;
		po3.R = r5; po3.G = g5; po3.B = b5;
	
		ZBufferTri(&p);

		po1.X = x5; po1.Y = y5; po1.Z = z5;
		po2.X = x1; po2.Y = y1; po2.Z = z1;
		po3.X = x2; po3.Y = y2; po3.Z = z2;

		po1.R = r5; po1.G = g5; po1.B = b5;
		po2.R = r1; po2.G = g1; po2.B = b1;
		po3.R = r2; po3.G = g2; po3.B = b2;
	
		ZBufferTri(&p);

		continue;

	    } else if (z1<ZCLIP) {

		FLOAT x4,y4,z4, x5,y5,z5;

		x4 = x1 + (ZCLIP-z1)*(x2-x1)/(z2-z1);
		y4 = y1 + (ZCLIP-z1)*(y2-y1)/(z2-z1);
		z4 = ZCLIP;

		r4 = r1 + (ZCLIP-z1)*(r2-r1)/(z2-z1);
		g4 = g1 + (ZCLIP-z1)*(g2-g1)/(z2-z1);
		b4 = b1 + (ZCLIP-z1)*(b2-b1)/(z2-z1);

		x5 = x1 + (ZCLIP-z1)*(x0-x1)/(z0-z1);
		y5 = y1 + (ZCLIP-z1)*(y0-y1)/(z0-z1);
		z5 = ZCLIP;

		r5 = r1 + (ZCLIP-z1)*(r0-r1)/(z0-z1);
		g5 = g1 + (ZCLIP-z1)*(g0-g1)/(z0-z1);
		b5 = b1 + (ZCLIP-z1)*(b0-b1)/(z0-z1);

		po1.X = x4; po1.Y = y4; po1.Z = z4;
		po2.X = x2; po2.Y = y2; po2.Z = z2;
		po3.X = x5; po3.Y = y5; po3.Z = z5;

		po1.R = r4; po1.G = g4; po1.B = b4;
		po2.R = r2; po2.G = g2; po2.B = b2;
		po3.R = r5; po3.G = g5; po3.B = b5;
	
		ZBufferTri(&p);

		po1.X = x5; po1.Y = y5; po1.Z = z5;
		po2.X = x2; po2.Y = y2; po2.Z = z2;
		po3.X = x0; po3.Y = y0; po3.Z = z0;

		po1.R = r5; po1.G = g5; po1.B = b5;
		po2.R = r2; po2.G = g2; po2.B = b2;
		po3.R = r0; po3.G = g0; po3.B = b0;
	
		ZBufferTri(&p);

		continue;

	    } else if (z2<ZCLIP) {

		FLOAT x4,y4,z4, x5,y5,z5;

		x4 = x2 + (ZCLIP-z2)*(x0-x2)/(z0-z2);
		y4 = y2 + (ZCLIP-z2)*(y0-y2)/(z0-z2);
		z4 = ZCLIP;

		r4 = r2 + (ZCLIP-z2)*(r0-r2)/(z0-z2);
		g4 = g2 + (ZCLIP-z2)*(g0-g2)/(z0-z2);
		b4 = b2 + (ZCLIP-z2)*(b0-b2)/(z0-z2);

		x5 = x2 + (ZCLIP-z2)*(x1-x2)/(z1-z2);
		y5 = y2 + (ZCLIP-z2)*(y1-y2)/(z1-z2);
		z5 = ZCLIP;

		r5 = r2 + (ZCLIP-z2)*(r1-r2)/(z1-z2);
		g5 = g2 + (ZCLIP-z2)*(g1-g2)/(z1-z2);
		b5 = b2 + (ZCLIP-z2)*(b1-b2)/(z1-z2);

		po1.X = x4; po1.Y = y4; po1.Z = z4;
		po2.X = x0; po2.Y = y0; po2.Z = z0;
		po3.X = x5; po3.Y = y5; po3.Z = z5;

		po1.R = r4; po1.G = g4; po1.B = b4;
		po2.R = r0; po2.G = g0; po2.B = b0;
		po3.R = r5; po3.G = g5; po3.B = b5;
	
		ZBufferTri(&p);

		po1.X = x5; po1.Y = y5; po1.Z = z5;
		po2.X = x0; po2.Y = y0; po2.Z = z0;
		po3.X = x1; po3.Y = y1; po3.Z = z1;

		po1.R = r5; po1.G = g5; po1.B = b5;
		po2.R = r0; po2.G = g0; po2.B = b0;
		po3.R = r1; po3.G = g1; po3.B = b1;
	
		ZBufferTri(&p);

		continue;
	    }


	case 2:

	    if (z0>=ZCLIP) {
	    /*

		     z0
		     /\
		    /  \
		   /    \
	       ---------------- ZCLIP
		 /        \
		z1--------z2

	    */

		x1 = x1 + (ZCLIP-z1)*(x0-x1)/(z0-z1);
		y1 = y1 + (ZCLIP-z1)*(y0-y1)/(z0-z1);
		r1 = r1 + (ZCLIP-z1)*(r0-r1)/(z0-z1);
		g1 = g1 + (ZCLIP-z1)*(g0-g1)/(z0-z1);
		b1 = b1 + (ZCLIP-z1)*(b0-b1)/(z0-z1);
		z1 = ZCLIP;
		
		x2 = x2 + (ZCLIP-z2)*(x0-x2)/(z0-z2);
		y2 = y2 + (ZCLIP-z2)*(y0-y2)/(z0-z2);
		r2 = r2 + (ZCLIP-z2)*(r0-r2)/(z0-z2);
		g2 = g2 + (ZCLIP-z2)*(g0-g2)/(z0-z2);
		b2 = b2 + (ZCLIP-z2)*(b0-b2)/(z0-z2);
		z2 = ZCLIP;

	    } else if (z1>=ZCLIP) {
	    /*

		     z1
		     /\
		    /  \
		   /    \
	       ---------------- ZCLIP
		 /        \
		z0--------z2

	    */
		x0 = x0 + (ZCLIP-z0)*(x1-x0)/(z1-z0);
		y0 = y0 + (ZCLIP-z0)*(y1-y0)/(z1-z0);
		r0 = r0 + (ZCLIP-z0)*(r1-r0)/(z1-z0);
		g0 = g0 + (ZCLIP-z0)*(g1-g0)/(z1-z0);
		b0 = b0 + (ZCLIP-z0)*(b1-b0)/(z1-z0);
		z0 = ZCLIP;

		x2 = x2 + (ZCLIP-z2)*(x1-x2)/(z1-z2);
		y2 = y2 + (ZCLIP-z2)*(y1-y2)/(z1-z2);
		r2 = r2 + (ZCLIP-z2)*(r1-r2)/(z1-z2);
		g2 = g2 + (ZCLIP-z2)*(g1-g2)/(z1-z2);
		b2 = b2 + (ZCLIP-z2)*(b1-b2)/(z1-z2);
		z2 = ZCLIP;

	    } else if (z2>=ZCLIP) {
	    /*

		     z2
		     /\
		    /  \
		   /    \
	       ---------------- ZCLIP
		 /        \
		z0--------z1

	    */

		x0 = x0 + (ZCLIP-z0)*(x2-x0)/(z2-z0);
		y0 = y0 + (ZCLIP-z0)*(y2-y0)/(z2-z0);
		r0 = r0 + (ZCLIP-z0)*(r2-r2)/(z2-z0);
		g0 = g0 + (ZCLIP-z0)*(g2-g2)/(z2-z0);
		b0 = b0 + (ZCLIP-z0)*(b2-b2)/(z2-z0);
		z0 = ZCLIP;

		x1 = x1 + (ZCLIP-z1)*(x2-x1)/(z2-z1);
		y1 = y1 + (ZCLIP-z1)*(y2-y1)/(z2-z1);
		r1 = r1 + (ZCLIP-z1)*(r2-r1)/(z2-z1);
		g1 = g1 + (ZCLIP-z1)*(g2-g1)/(z2-z1);
		b1 = b1 + (ZCLIP-z1)*(b2-b1)/(z2-z1);
		z1 = ZCLIP;
	    } 
	    break;
	}

        po1.X = x0; po1.Y = y0; po1.Z = z0;
        po2.X = x1; po2.Y = y1; po2.Z = z1;
        po3.X = x2; po3.Y = y2; po3.Z = z2;

	po1.R = r0; po1.G = g0; po1.B = b0;
	po2.R = r1; po2.G = g1; po2.B = b1;
	po3.R = r2; po3.G = g2; po3.B = b2;

	if ((po1.Z<ZCLIP) || (po2.Z<ZCLIP) || (po3.Z<ZCLIP)) 
	    return -1;

        ZBufferTri(&p);
    }

    return 0;
}


Object3D::~Object3D()
{
    delete [] headVertex;
    delete [] headTriangle;

    Material *tmpm = headMaterial;

    while (tmpm) {
	headMaterial = tmpm;
	tmpm = tmpm->GetNextNode();
	delete headMaterial;
    }
}
