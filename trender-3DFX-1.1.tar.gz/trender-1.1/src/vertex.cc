/*
 *  trender - 3D Studio .ASC files realtime renderer
 *  Copyright (C) 1999  Thanassis Tsiodras (ttsiod@softlab.ntua.gr)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "vgalib.h"
#include "3dtypes.h"
#include "defines.h"

#define AMBIENT 16
#define SPEC_COEFF 5.0
#define SPECULAR

Vertex::init(FLOAT x, FLOAT y, FLOAT z)
{
    usX = x; usY = y; usZ = z;

    fNormalX = fNormalY = fNormalZ = 0;
    fTransformedX = fTransformedY = fTransformedZ = 0;
    always_draw = FALSE;
    intensity = 0;
}

void Vertex::Illuminate(Light *light, Camera *camera)
{
    FLOAT fSumm;
    FLOAT lx,ly,lz;   /* light vector */
    FLOAT rx,ry,rz;   /*  reflection  */
    FLOAT fSpecularIntensity = 0.0;

/* Diffuse light */
    lx = light->GetX() - usX;
    ly = light->GetY() - usY;
    lz = light->GetZ() - usZ;

    fSumm=sqrt(lx*lx + ly*ly + lz*lz);
    if (fSumm<1e-5) {
        intensity = AMBIENT;
	return;
    }

    /* normalize light vector */
    lx/=fSumm;
    ly/=fSumm;
    lz/=fSumm;

    /* reflection vector: r = -light + 2*normal*cos phi,
       where phi the angle between normal and light

       first, r = -light (normalized * 128) */

    rx = -lx;
    ry = -ly;
    rz = -lz;

    /* intensity = normalized light . normalized normal
       ranges from 0..128 */
    intensity = (128.0*(lx*fNormalX +
			ly*fNormalY +
			lz*fNormalZ));

/* check if vertex is looking away from the light... */
    if (intensity<=0) {
	intensity=AMBIENT; // ambient intensity
	return;
    }
     
/* Specular light */

    /* First, complete the reflection calculation:

       reflection vector: r = -light + 2*normal*cos phi,
       where phi the angle between normal and light.

       We have just calculated diffuse intensity as normal . light,
       so cos phi = intensity/|normal|x|light|. And since normal
       and light have a |.| of 128, ... */

#ifdef SPECULAR
    rx += 2.0*intensity*fNormalX/128.0;
    ry += 2.0*intensity*fNormalY/128.0;
    rz += 2.0*intensity*fNormalZ/128.0;

    FLOAT ex, ey, ez; // eye vector

    ex = camera->GetEyeX() - usX;
    ey = camera->GetEyeY() - usY;
    ez = camera->GetEyeZ() - usZ;

    // normalize eye vector 
    fSumm=sqrt(ex*ex + ey*ey + ez*ez);
    if (fSumm<1e-5) {
	// intensity: 		0..255-AMBIENT-128, diffuse
	goto ambient;
    }
    ex = ex/fSumm; ey = ey/fSumm; ez = ez/fSumm;

    // normalize reflection vector
    fSumm=sqrt(rx*rx + ry*ry + rz*rz);
    if (fSumm<1e-5) {
	// intensity: 		0..255-AMBIENT-128, diffuse
	goto ambient;
    }
    rx = rx/fSumm; ry = ry/fSumm; rz = rz/fSumm;

    fSpecularIntensity = (ex*rx + ey*ry + ez*rz);

    if (fSpecularIntensity < 0) {
	// intensity: 		0..255-AMBIENT-128, diffuse
	goto ambient;
    }

// Nasty coding hack, specific for SPEC_COEFF 8.0
// normal code is: pow(fSpecularIntensity, SPEC_COEFF)
// Especially for 16.0, this code gives a 25% increase in speed!

    fSpecularIntensity *= fSpecularIntensity;
    fSpecularIntensity *= fSpecularIntensity;
    fSpecularIntensity *= fSpecularIntensity;
    fSpecularIntensity *= fSpecularIntensity;

    // intensity: 		0..255-AMBIENT-128, diffuse

    // specularIntensity: 	0..127, specular
    intensity += (fSpecularIntensity*(255-AMBIENT-128)); //0..255
#endif

/* Ambient */
ambient:
    intensity+=AMBIENT;
    if (intensity>255)intensity=255;
    if (intensity<0)intensity=0;
}

void Vertex::Transform(Camera *camera)
{
    FLOAT result0, result1, result2;

    result0 = camera->m00*usX + camera->m01*usY +
              camera->m02*usZ + camera->m03;
    result1 = camera->m10*usX + camera->m11*usY +
              camera->m12*usZ + camera->m13;
    result2 = camera->m20*usX + camera->m21*usY +
              camera->m22*usZ + camera->m23;
    
    fTransformedX = result0;
    fTransformedY = result1;
    fTransformedZ = result2;
    
}
